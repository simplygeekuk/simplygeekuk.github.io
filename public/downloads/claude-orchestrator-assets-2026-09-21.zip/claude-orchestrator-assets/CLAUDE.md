# CLAUDE.md

Guidance for Claude Code (claude.ai/code) working in this repository.

## Project Overview

VMware VCF Automation content, built as a Maven multi-module project inheriting from the VMware PSCoE parent v4.25.0. It orchestrates vRealize Orchestrator (vRO) and vRealize Automation (vRA) against Active Directory, Ansible Automation Platform, GitLab, Infoblox, SaltStack Config, and vCenter.

## Commands

Never run Maven. Builds, tests, pushes and pulls belong to the user: give them the command rather than executing it. Every Maven command is in the `vro-maven-commands` skill, which is the only place they are written down. Verify changes with ESLint and Prettier instead.

| Purpose      | Command                  |
| ------------ | ------------------------ |
| Lint         | `npx eslint source/`     |
| Format check | `npx prettier --check .` |
| Format fix   | `npx prettier --write .` |

## Layout

Five Simplygeek Maven modules under `source/`: `vro-actions` (JavaScript action files holding the core business logic, and the most actively developed module), `vro-workflows` (XML workflow definitions), `vro-elements` (configuration elements and resources), `vra-content` (blueprints, policies, subscriptions), and `environments` (per-tenant overrides of `vro-elements` for tenant-dev, tenant-uat, tenant-preprod, and tenant-prod).

Actions live under `source/vro-actions/src/main/resources/com/simplygeek/`, one directory per integration: `ad/`, `ansible/`, `gitlab/`, `infoblox/`, `vcenter/`, `salt/`, `utils/`, `rest/`. Two paths are not obvious from the names:

- `vcf/automation/` covers catalog, deployment, IaaS custom naming, policy, project, provisioning, and subscriptions.
- `vcf/orchestrator/` holds `logging/Logger`, `locking/LockingService`, and `configurations/ConfigElementService`.

Jasmine tests live under `source/vro-actions/src/test/resources/`.

Polyglot actions live in a polyglot module under `src/<actionName>/`, one directory per action with a `polyglot.json` descriptor; find the modules with `git ls-files "*/polyglot.json"` and see the module README. Action environments under `src/resources/environments/` are built and pushed from the module, bundle included, and must not be edited in Orchestrator; the README explains why. ESLint and the JSDoc rules do not apply to polyglot handlers; Prettier still formats their `.json` files.

## Conventions

- Every action file is an IIFE. Services follow a constructor plus prototype pattern.
- One service module per API, using classical inheritance. Never add API-specific methods to a shared or base client class.
- JSDoc is mandatory. ESLint enforces it on all classes, methods, and functions, including `@param` names and types and `@returns`.
- Argument errors come in three kinds. A required argument that is missing or not of its type throws `ReferenceError` from one guard, with the message `"<param> is required and must be of type '<type>'"`. An optional argument is absent when it is `undefined` or `null`; one that is supplied with the wrong type throws `TypeError`, whatever its truthiness. A value of the right type that is not acceptable, such as an unsupported option or a malformed URI, throws `RangeError`.
- Handle errors explicitly. No silently discarded exceptions.

## Code style

ESLint (flat config) and Prettier at the repository root are the source of truth. The settings worth knowing before writing code: 4-space indent, 80-character lines, CRLF endings, double quotes, mandatory semicolons, blank-line padding between statements, and a newline after an `if` condition.

`eslint/orchestrator-globals.js` defines ~180 vRO platform globals such as `System`, `Server`, and `LockingSystem` that action files use without import. `eslint/jasmine-globals.js` does the same for Jasmine test globals.

## Claude Code assets

Skills in `.claude/skills/`: `new-vro-module` for new clients, DTOs, and actions; `vro-jasmine-tests` for Jasmine specs with vRO global mocking; `new-vro-workflow` for 4-file workflow sets; `vro-polyglot-action` for polyglot actions and action environments; `vro-maven-commands` for the push, pull, server clean-up and archetype commands the user runs. The `vro-code-reviewer` agent in `.claude/agents/` checks changed files against these conventions before a commit.
