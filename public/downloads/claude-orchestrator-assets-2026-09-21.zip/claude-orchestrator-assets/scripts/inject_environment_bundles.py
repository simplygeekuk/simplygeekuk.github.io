"""Add pre-built dependency bundles to action environments in a vRO package.

The PSCoE build tools (4.25.0) push an action environment as its JSON
definition only, and Orchestrator then downloads the dependencies from a
package index. This step reproduces what an Orchestrator export carries
instead: a bundle with the environment's Python modules already in
place, so nothing is downloaded on the appliance and modules that live
in this repository can be part of the environment.

For every ``<name>.json`` in the environments directory that has a
sibling ``<name>.requirements.txt``, the script

1. builds a wheel for every line of the requirements file that names a
   local project directory (relative to the environments directory),
   then pip-installs those wheels and the remaining requirements with
   ``--target``, honouring any ``PIP_*`` variables in the environment so
   wheels can be selected for the Orchestrator runtime;
2. zips the result as ``environment-bundle/lib/...``, the layout of an
   Orchestrator export;
3. writes the zip as ``elements/<id>/bundle`` in the package, records
   its SHA-256 in the element's ``data`` JSON as ``bundleHash``, and
   re-signs the changed element files the way vropkg signs them: RSA
   PKCS#1 v1.5 over the file bytes with an MD5 digest.

Signing needs either the ``cryptography`` Python package or an
``openssl`` executable on the PATH.

Run from Maven (see pom.xml) or by hand::

    python scripts/inject_environment_bundles.py \\
        --package target/<groupId>.<artifactId>-<version>.package \\
        --environments src/resources/environments \\
        --work out/environments \\
        --private-key path/to/private_key.pem \\
        --certificate path/to/cert.pem \\
        --key-pass secret
"""

import argparse
import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile

BUNDLE_ROOT = "environment-bundle/lib"
ENVIRONMENT_TYPE = "ActionEnvironment"
SKIP_DIRS = {"__pycache__", "bin"}
PLATFORM_VARIABLES = (
    "PIP_PLATFORM",
    "PIP_PYTHON_VERSION",
    "PIP_IMPLEMENTATION",
    "PIP_ABI",
    "PIP_ONLY_BINARY",
)


def log(message):
    """Print a progress line in the style of the surrounding build output."""
    print("[inject-environment-bundles] " + message, flush=True)


def fail(message):
    """Abort the build with a message on stderr."""
    print("[inject-environment-bundles] ERROR: " + message, file=sys.stderr)
    sys.exit(1)


def load_signer(private_key_path, certificate_path, key_pass):
    """Return a function that signs bytes the way vropkg does.

    vropkg calls Node's ``crypto.createSign('MD5')`` with the private
    key, which is RSA PKCS#1 v1.5 with an MD5 digest.
    """
    if not os.path.isfile(private_key_path):
        fail("private key not found: " + private_key_path)

    if not os.path.isfile(certificate_path):
        fail("certificate not found: " + certificate_path)

    with open(private_key_path, "rb") as handle:
        key_pem = handle.read()

    password = key_pass.encode() if key_pass else None

    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding

        private_key = serialization.load_pem_private_key(key_pem, password)

        def sign(data):
            return private_key.sign(data, padding.PKCS1v15(), hashes.MD5())

        log("signing with the cryptography package")
        return sign
    except ImportError:
        pass

    openssl = shutil.which("openssl")

    if not openssl:
        fail(
            "signing needs the cryptography package "
            "(python -m pip install cryptography) or openssl on the PATH"
        )

    def sign(data):
        with tempfile.NamedTemporaryFile(delete=False) as handle:
            handle.write(data)
            data_path = handle.name

        try:
            command = [openssl, "dgst", "-md5", "-sign", private_key_path]

            if key_pass:
                command += ["-passin", "pass:" + key_pass]

            return subprocess.run(
                command + [data_path], check=True, capture_output=True
            ).stdout
        finally:
            os.unlink(data_path)

    log("signing with " + openssl)
    return sign


def pip(arguments, cwd, cross_platform):
    """Run pip. Without cross_platform the PIP_* platform variables are dropped.

    Building a wheel from a local project must run for the build
    machine, so the platform selection meant for the install step would
    make pip refuse it.
    """
    environment = dict(os.environ)

    if not cross_platform:
        for name in PLATFORM_VARIABLES:
            environment.pop(name, None)

    command = [sys.executable, "-m", "pip", "--disable-pip-version-check"]
    subprocess.run(command + arguments, check=True, cwd=cwd, env=environment)


def split_requirements(requirements_path):
    """Return (index requirement lines, local project directories)."""
    base = os.path.dirname(requirements_path)
    index_lines = []
    local_projects = []

    with open(requirements_path, encoding="utf-8") as handle:
        for raw in handle:
            line = raw.strip()

            if not line or line.startswith("#"):
                continue

            candidate = os.path.normpath(os.path.join(base, line))

            if os.path.isdir(candidate):
                local_projects.append(candidate)
            else:
                index_lines.append(line)

    return index_lines, local_projects


def normalise(name):
    """Return a package name the way pip compares them."""
    return re.sub(r"[-_.]+", "-", name).lower()


def check_definition(definition, requirements_path):
    """Fail unless every dependency the environment declares is pinned.

    The JSON is what Orchestrator displays and what it would rebuild
    from; the requirements file is what the bundle holds. They must
    agree, or the pushed environment says one thing and carries another.
    """
    index_lines, _ = split_requirements(requirements_path)
    pinned = {}

    for line in index_lines:
        if "==" in line:
            name, version = line.split("==", 1)
            pinned[normalise(name.strip())] = version.strip()

    problems = []

    for name, version in definition.get("dependencies", {}).items():
        actual = pinned.get(normalise(name))

        if actual is None:
            problems.append("%s is not pinned in %s" % (name, requirements_path))
        elif actual != version:
            problems.append(
                "%s is %s in the environment but %s in %s"
                % (name, version, actual, requirements_path)
            )

    if problems:
        fail(
            "environment %s and its requirements disagree: %s"
            % (definition.get("name"), "; ".join(problems))
        )


def install_requirements(requirements_path, work_dir, lib_dir):
    """Build local projects as wheels, install everything, return the wheels."""
    index_lines, local_projects = split_requirements(requirements_path)
    wheelhouse = os.path.join(work_dir, "wheelhouse")

    for directory in (lib_dir, wheelhouse):
        if os.path.isdir(directory):
            shutil.rmtree(directory)

        os.makedirs(directory)

    for project in local_projects:
        log("building wheel for " + project)
        pip(
            ["wheel", "--no-deps", "--wheel-dir", wheelhouse, project],
            cwd=work_dir,
            cross_platform=False,
        )

    wheels = sorted(glob.glob(os.path.join(wheelhouse, "*.whl")))
    filtered = os.path.join(work_dir, "requirements.txt")

    with open(filtered, "w", encoding="utf-8") as handle:
        handle.write("\n".join(index_lines) + "\n")

    log("pip install into " + lib_dir)
    pip(
        ["install", "--requirement", filtered, "--target", lib_dir, "--upgrade"]
        + wheels,
        cwd=work_dir,
        cross_platform=True,
    )

    return [os.path.basename(wheel) for wheel in wheels]


def build_bundle(lib_dir, bundle_path):
    """Zip lib_dir as environment-bundle/lib and return the SHA-256."""
    with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as bundle:
        for root, dirs, files in os.walk(lib_dir):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)

            for name in sorted(files):
                full = os.path.join(root, name)
                relative = os.path.relpath(full, lib_dir).replace(os.sep, "/")
                bundle.write(full, BUNDLE_ROOT + "/" + relative)

    digest = hashlib.sha256()

    with open(bundle_path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)

    return digest.hexdigest()


def find_environment_element(package, environment_id):
    """Return the elements/<id> prefix for an environment, or fail."""
    prefix = "elements/%s/" % environment_id

    if prefix + "info" not in package.namelist():
        fail("environment %s is not in the package" % environment_id)

    info = package.read(prefix + "info").decode("utf-8", "replace")

    if ">%s<" % ENVIRONMENT_TYPE not in info:
        fail("element %s is not an %s" % (environment_id, ENVIRONMENT_TYPE))

    return prefix


def rewrite_package(package_path, replacements):
    """Write a copy of the package with some entries replaced, then swap."""
    temp_path = package_path + ".tmp"

    with zipfile.ZipFile(package_path) as source, zipfile.ZipFile(
        temp_path, "w", zipfile.ZIP_DEFLATED
    ) as target:
        for item in source.infolist():
            if item.filename in replacements:
                continue

            target.writestr(item, source.read(item.filename))

        for name, data in replacements.items():
            target.writestr(name, data)

    os.replace(temp_path, package_path)


def inject(package_path, environments_dir, work_dir, sign):
    """Build and inject a bundle for every environment with requirements."""
    done = 0

    for entry in sorted(os.listdir(environments_dir)):
        if not entry.endswith(".json"):
            continue

        name = entry[: -len(".json")]
        requirements = os.path.join(environments_dir, name + ".requirements.txt")

        if not os.path.isfile(requirements):
            log("%s has no requirements file, leaving it to Orchestrator" % name)
            continue

        with open(os.path.join(environments_dir, entry), encoding="utf-8") as f:
            definition = json.load(f)

        environment_id = definition["id"]
        environment_work = os.path.join(work_dir, name)
        lib_dir = os.path.join(environment_work, "lib")
        bundle_path = os.path.join(work_dir, name + ".bundle.zip")

        os.makedirs(environment_work, exist_ok=True)
        check_definition(definition, requirements)
        wheels = install_requirements(requirements, environment_work, lib_dir)

        for wheel in wheels:
            log("%s: local project bundled as %s" % (name, wheel))

        bundle_hash = build_bundle(lib_dir, bundle_path)

        with zipfile.ZipFile(package_path) as package:
            prefix = find_environment_element(package, environment_id)
            data = json.loads(package.read(prefix + "data").decode("utf-8"))

        data["bundleHash"] = bundle_hash
        data_bytes = json.dumps(data, separators=(", ", ": ")).encode("utf-8")

        with open(bundle_path, "rb") as handle:
            bundle_bytes = handle.read()

        rewrite_package(
            package_path,
            {
                prefix + "bundle": bundle_bytes,
                prefix + "data": data_bytes,
                prefix + "content-signature": sign(data_bytes),
                "signatures/" + prefix + "bundle": sign(bundle_bytes),
                "signatures/" + prefix + "data": sign(data_bytes),
            },
        )
        log(
            "%s: bundle of %d bytes injected as %s"
            % (name, len(bundle_bytes), prefix + "bundle")
        )
        done += 1

    log("%d environment bundle(s) injected into %s" % (done, package_path))


def main():
    """Parse arguments and run the injection."""
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--package", required=True, help="vRO .package to modify")
    parser.add_argument(
        "--environments",
        required=True,
        help="directory holding <name>.json and <name>.requirements.txt",
    )
    parser.add_argument("--work", required=True, help="scratch directory")
    parser.add_argument("--private-key", required=True, help="PEM private key")
    parser.add_argument("--certificate", required=True, help="PEM certificate")
    parser.add_argument("--key-pass", default="", help="private key passphrase")
    args = parser.parse_args()

    if not os.path.isfile(args.package):
        fail("package not found: " + args.package)

    if not os.path.isdir(args.environments):
        log("no environments directory, nothing to do")
        return

    os.makedirs(args.work, exist_ok=True)
    sign = load_signer(args.private_key, args.certificate, args.key_pass)
    inject(
        os.path.abspath(args.package),
        os.path.abspath(args.environments),
        os.path.abspath(args.work),
        sign,
    )


if __name__ == "__main__":
    main()
