---
name: new-vro-workflow
description: Use when creating, renaming, or moving a vRO workflow under source/vro-workflows. Every workflow is a 4-file set (.xml, .element_info.xml, .form.json, .tags.xml) sharing one basename, with a fresh GUID id and a categoryPath matching the directory.
---

# New vRO Workflow

## The 4-file contract

A workflow is **four sibling files sharing one basename** in
`source/vro-workflows/src/main/resources/Workflow/<Category path>/`:

| File                      | Contents                                                                   |
| ------------------------- | -------------------------------------------------------------------------- |
| `<Name>.xml`              | The workflow definition (GUID `id`, inputs, workflow-items)                |
| `<Name>.element_info.xml` | Java Properties: `categoryPath`, `name`, `type=Workflow`, `id` (same GUID) |
| `<Name>.form.json`        | The request input form (layout + schema)                                   |
| `<Name>.tags.xml`         | Tags (`<tags/>` when empty)                                                |

Canonical exemplar quadruple to copy from:
`Workflow/Simplygeek/VCF Automation/Day2 Actions/Deployment - Schedule Deletion.*`

Workflow basenames are display names with spaces, e.g.
`VM - Schedule Deletion`.

## GUID rules

- Generate a **fresh GUID** for each new workflow:
  PowerShell `[guid]::NewGuid()`.
- The GUID appears in **two places and must match**: the `id` attribute
  on the `<workflow>` root element and the `id` entry in
  `element_info.xml`.
- Never copy an existing workflow's id. Confirm uniqueness:
  `grep -r "<the-guid>" "source/vro-workflows/src/main/resources"`.

## Per-file requirements

### `<Name>.xml`

Root: `<workflow xmlns="http://vmware.com/vco/workflow" ...>` with
GUID `id`, `root-name` pointing at the first item,
`object-name="workflow:name=generic"`. Contains:

- `<display-name>` / `<description>` as CDATA.
- `<attrib name type>` elements for workflow attributes (constants),
  each with a `<value encoded="n">` CDATA and a description.
- `<input>` with `<param name type>` + CDATA descriptions.
- `<workflow-item>` nodes chained via `out-name`; `type="end"` for the
  terminus, `type="task"` for scriptable tasks. Each task binds inputs
  in `<in-binding>` (`<bind name type export-name>`).

**Scriptlets delegate — business logic lives in vro-actions.** The
CDATA `<script>` should only instantiate a Logger (source `"Workflow"`,
name = workflow display name) and call a `com.simplygeek.*` action:

```javascript
var log = new (System.getModule(
    "com.simplygeek.vcf.orchestrator.logging"
).Logger())("Workflow", "Deployment - Schedule Deletion");

var result = System.getModule(
    "com.simplygeek.vcf.automation.plugin.deployment"
).scheduleDeploymentDeletion(deploymentId, tagKey, tagValue, powerOff);

log.info("Summary: " + JSON.stringify(result));
```

### `<Name>.element_info.xml`

Java Properties XML. `categoryPath` is the **dot-separated directory
path relative to `Workflow/`, keeping spaces**:
directory `Workflow/Simplygeek/VCF Automation/Day2 Actions/` →
`<entry key="categoryPath">Simplygeek.VCF Automation.Day2 Actions</entry>`.
`name` must equal the file basename.

### `<Name>.form.json`

Two top-level parts: `layout` (pages → sections → fields, each field
`{id, display, state}` — `textField`, `checkbox`, etc.) and `schema`
(per-input `{id, type: {dataType}, label, constraints, default?}`).
Field/schema `id`s must match the workflow's `<input>` param names.
Ends with `"options": {"externalValidations": []}` and `"itemId": ""`.

### `<Name>.tags.xml`

`<?xml version="1.0" encoding="UTF-8"?>` + `<tags/>` unless tags are
needed.

## Renames and moves

Move **all four files together** with `git mv`, and update
`categoryPath` (and `name`, on rename) in `element_info.xml`. The GUID
stays the same for a rename/move — it only changes for a genuinely new
workflow.

## Verify

Check XML well-formedness only (PowerShell:
`[xml](Get-Content "<file>")` for each `.xml`) and JSON validity for
the form. **Never run Maven** — if a package build is needed, give
the user the command for the `vro-workflows` module from
the `vro-maven-commands` skill.
