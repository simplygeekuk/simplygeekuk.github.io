---
name: vro-jasmine-tests
description: Use when writing or updating Jasmine unit tests for vRO actions. Tests live in source/vro-actions/src/test/resources mirroring the main tree, named <ClassName>.test.js, and require a specific vRO global-mocking pattern (System, System.getModule, LockingSystem). Also defines how to verify tests without running Maven.
---

# vRO Jasmine Tests

## Placement and naming

Specs live under `source/vro-actions/src/test/resources/com/simplygeek/`
mirroring the main tree, named `<ClassName>.test.js`. Example: the spec
for `main/resources/com/simplygeek/vcf/orchestrator/locking/LockingService.js`
is `test/resources/com/simplygeek/vcf/orchestrator/locking/LockingService.test.js`.

Read both existing specs before writing a new one — they are the
canonical pattern:

- `test/resources/com/simplygeek/vcf/orchestrator/locking/LockingService.test.js`
- `test/resources/com/simplygeek/vcf/orchestrator/logging/Logger.test.js`

Test files may use modern JS (`const`, `let`, arrow functions) even
though action files are ES5. `eslint.config.js` holds the two apart:
actions are parsed as ECMAScript 5, so newer syntax in one is a lint
error, and specs as ECMAScript 2015 with the Jasmine globals and
`no-undef` off.

## The loading model (non-obvious — read this)

The PSCoE test harness provides a global `System.getModule` at
spec-load time, so the module under test is obtained **in the describe
body** (not in `beforeEach`):

```javascript
const LockingService = System.getModule(
    "com.simplygeek.vcf.orchestrator.locking"
).LockingService();
```

Per-test mocks are then installed by **reassigning the bare globals**
inside `beforeEach` — no `let`/`const`, no `global.` prefix:

```javascript
const path = require("path");

describe("LockingService", function () {
    let capturedName;

    beforeEach(function () {
        const loggerInstance = {
            debug: jasmine.createSpy("debug"),
            warn: jasmine.createSpy("warn"),
            info: jasmine.createSpy("info"),
            error: jasmine.createSpy("error"),
        };

        function LoggerConstructor(type, name) {
            capturedName = name;
            return loggerInstance;
        }

        const getModuleMock = jasmine
            .createSpy("getModule")
            .and.callFake(function (moduleName) {
                if (moduleName === "com.simplygeek.vcf.orchestrator.logging") {
                    return {
                        Logger: jasmine
                            .createSpy("Logger")
                            .and.returnValue(LoggerConstructor),
                    };
                }
                throw new Error("Unknown module: " + moduleName);
            });

        System = {
            getModule: getModuleMock,
            sleep: jasmine.createSpy("sleep"),
        };

        LockingSystem = {
            lock: jasmine.createSpy("lock"),
            unlock: jasmine.createSpy("unlock"),
        };
    });
});
```

Key rules:

- Mock `System.getModule` with `.and.callFake` switching on the module
  name; throw `Error("Unknown module: " + moduleName)` for anything
  unexpected so missing mocks fail loudly.
- Mock every vRO global the module touches (`System`, `LockingSystem`,
  etc.) with `jasmine.createSpy` methods.
- When a test needs a **real** dependency module rather than a mock,
  evaluate its source. `require()` does not work: an action file is one
  parenthesised function expression with no `module.exports`, so
  `require` returns `{}`. Evaluating the text returns the function,
  which is exactly what `System.getModule(...).<Name>` hands back on
  Orchestrator:

```javascript
const fs = require("fs");
const path = require("path");
const vm = require("vm");

/**
 * Loads an action from the main tree as Orchestrator exposes it.
 * @param {string} actionPath - Path below src/main/resources.
 * @returns {Function} The action's IIFE, not yet invoked.
 */
function loadAction(actionPath) {
    let directory = __dirname;

    // Walk up to the module, from the source tree or a copy under target/.
    while (!fs.existsSync(path.join(directory, "src/main/resources"))) {
        const parent = path.dirname(directory);

        if (parent === directory) {
            throw new Error("src/main/resources not found above " + __dirname);
        }

        directory = parent;
    }

    const file = path.join(directory, "src/main/resources", actionPath);

    return vm.runInThisContext(fs.readFileSync(file, "utf8"), {
        filename: file,
    });
}
```

and in the `System.getModule` mock:

```javascript
if (moduleName === "com.simplygeek.vcf.orchestrator.locking") {
    return {
        LockingService: loadAction(
            "com/simplygeek/vcf/orchestrator/locking/LockingService.js"
        ),
    };
}
```

`runInThisContext` evaluates in the global scope, so the action sees
the `System` and `LockingSystem` globals the spec assigned. Verified
with Node against `LockingService.js` from the source tree; the walk
up to `src/main/resources` is there because the harness may run specs
from a copy under `target/`, and that path has not been exercised
under Maven.

## What to test in this codebase

- Constructor and method guard clauses: the error type and the exact
  message, via
  `.toThrowError(TypeError, "x must be of type 'string'")`. Cover the
  three kinds in CLAUDE.md: `ReferenceError` for a required argument,
  `TypeError` for a supplied optional of the wrong type (try `false`
  and `0`, not only a wrong truthy value), `RangeError` for an
  unsupported value.
- Logger name capture (the class passes its own name to Logger).
- Happy paths with spied REST verb methods
  (`httpGet`/`httpPost`/...) returning canned `{ contentAsString }`
  responses.
- Retry/backoff behavior via the `System.sleep` spy
  (`.and.returnValues(false, true)` on the dependency, then assert
  `System.sleep` was called).

## Backfill priority

When asked to "add tests" generally, start with modules that have pure
logic and few vRO dependencies:

1. `vcf/orchestrator/*` (Logger, LockingService, ConfigElementService)
2. `utils/*` (StringUtils, ArrayUtils, DateUtils)
3. `rest/HttpRestClient.js`
4. Object model DTOs (`*/objects/*.js` — pure validation, no mocking)

before deep API clients.

## Verify

```bash
npx eslint <spec files>
npx prettier --check <spec files>
```

**Never run Maven.** Give the user the test command from
the `vro-maven-commands` skill; its output is parsed by
`scripts/parse-summary.js`.
