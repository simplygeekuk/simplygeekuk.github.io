---
name: vro-maven-commands
description: Use whenever the user needs a Maven command for this repository - building or testing a module, pushing it to an Orchestrator or VCF Automation tenant, pulling content back, cleaning packages off the server, or scaffolding a new Build Tools module from an archetype. The single home for every mvn command here. Gives the exact command and states what it overwrites or deletes. Claude never runs these.
---

# vRO Maven Commands

**Never run these.** Give the user the command, say where it runs (the
repository root unless stated) and state its effect first. Push, pull
and clean all overwrite or delete something.

Two values change per command:

- **Profile** - `-Ptenant-dev`, `-Ptenant-uat`, `-Ptenant-preprod` or
  `-Ptenant-prod`. The profiles hold the server connection and live in
  the user's Maven `settings.xml`, not in this repository. The names
  are this estate's: they match the directories under
  `source/environments/`. Default to
  `tenant-dev`; name any other tenant only when the user asked for it.
- **Module** - `-pl "source/<module>"`.

This skill is the one place Maven commands are written down. Other
skills and `CLAUDE.md` point here; add a new command here, not there.

## Build and test

Effect: local only. Nothing reaches a server.

| Purpose                                | Command                                    |
| -------------------------------------- | ------------------------------------------ |
| Build every module in the root reactor | `mvn clean install`                        |
| Build one module                       | `mvn clean install -pl source/vro-actions` |
| Unit tests                             | `mvn test -pl source/vro-actions`          |

- `source/vro-actions` is the only module with a test tree
  (`src/test/resources`, Jasmine). `mvn test` on any other module has
  nothing to run.
- Test output is parsed by `scripts/parse-summary.js`.
- `source/environments/*` is not in the root reactor, so a plain
  `mvn clean install` never builds the tenant overrides.
- A module outside the five under `source/` documents its own build
  and push in its README. Use that command, not one adapted from here.

## Polyglot modules

Find them with `git ls-files "*/polyglot.json"`; the module is the
directory above `src/`.

```
mvn clean install -pl "<polyglot module path>"
mvn clean package vrealize:push -Ptenant-dev -pl "<polyglot module path>"
```

A polyglot module differs from the others:

- **Push effect** - it replaces the module's polyglot actions and any
  action environment under `src/resources/environments/`, bundle
  included. An edit made to that environment in Orchestrator is lost.
- **No pull** - Build Tools does not support pulling polyglot or ABX
  content, so there is no `vro:pull` for a polyglot module. The
  repository is the only source: a change made to a polyglot action in
  Orchestrator cannot be brought back and the next push overwrites it.
- **Build machine needs** - Node.js and npm, plus `pip3` for Python
  actions. A module that bundles environments at build time also
  needs `python` with either the `cryptography` package or `openssl`
  on the PATH; its README says so.
- **Different Python executable** - add `-Dpython.executable=python3`
  where the module POM defines that property.
- **No pip variables** - where the module POM sets `PIP_PLATFORM` and
  the rest on the Maven build step, they are needed only for a direct
  `npm run build` in the module directory.
- **No Maven tests** - a repository-owned Python package is tested
  with `python -m pytest` in its own directory, which Claude can run.
- **Push order** - push polyglot and JavaScript actions before the
  workflows that call them.

What changes in an action or environment before a push (descriptor,
version bumps, callers) belongs to the `vro-polyglot-action` skill.

## Push

Effect: builds the package and imports it into the tenant, replacing
the server copy of every element in the package.

Common flags, used on every push:

```
-DskipTests -Dlicense.skip -Dlicense.skipAddThirdParty=true -DskipInstallNodeDeps=true
```

| Content                    | Command                                                                                                           |
| -------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| Actions                    | `mvn clean package vrealize:push <common> -Ptenant-dev -pl "source/vro-actions"`                                  |
| Workflows                  | `mvn clean package vrealize:push <common> -Ptenant-dev -pl "source/vro-workflows"`                                |
| vRA content                | `mvn clean package vrealize:push <common> -Ptenant-dev -pl "source/vra-content"`                                  |
| Elements (global)          | `mvn clean package vrealize:push <common> <values> -Ptenant-dev -pl "source/vro-elements"`                        |
| Elements (tenant override) | `mvn clean package vrealize:push <common> <values> -Ptenant-dev -f "source/environments/tenant-dev/vro-elements"` |

`<values>` is needed for elements only. Without it the import keeps
the attribute values already on the server:

```
-Dvro.packageImportConfigurationAttributeValues=true -Dvro.packageImportConfigSecureStringAttributeValues=true
```

Points to get right:

- The tenant override uses `-f`, not `-pl`: the environment modules
  are not in the root reactor. The directory and the profile must name
  the same tenant.
- Always write the expanded command out in full for the user. Do not
  hand them `<common>` or `<values>`.
- When several modules changed, push elements, then actions, then
  workflows, then vRA content. Later ones reference earlier ones.
- `-DskipTests` is there because push is not the test step. If the
  actions changed, give `mvn test -pl source/vro-actions` first.

## Pull

Effect: overwrites files in the working tree with the server copy.
Tell the user to commit or stash first so the pull shows up as a diff.

```
mvn vro:pull -Ptenant-dev -pl "source/vro-actions"
mvn vro:pull -Ptenant-dev -pl "source/vro-workflows"
mvn vra-ng:pull -Ptenant-dev -pl "source/vra-content"
```

Polyglot and ABX modules cannot be pulled; see the section above.

To pull a different server package into a module:

```
mvn vro:pull -DpackageName=com.vmware.pscoe.library.ssh -Ptenant-dev -pl "source/vro-workflows"
```

## Clean packages off the server

Effect: deletes packages, and with `-DincludeDependencies=true` their
dependency packages, from the tenant. It cannot be undone from here.

Remove only the current version:

```
mvn vrealize:clean -DcleanUpLastVersion=true -DcleanUpOldVersions=false -DincludeDependencies=true -Ptenant-dev -pl "source/vro-actions"
```

Remove old versions and keep the current one:

```
mvn vrealize:clean -DcleanUpLastVersion=false -DcleanUpOldVersions=true -DincludeDependencies=true -Ptenant-dev -pl "source/vro-actions"
```

The same two commands work with `-pl "source/vro-workflows"`.

## Scaffold a new module

Run from the directory that will hold the module, normally
`source/`. It creates a directory named after `artifactId`.

```
mvn archetype:generate -DinteractiveMode=false -DarchetypeGroupId=<group> -DarchetypeArtifactId=<archetype> -DarchetypeVersion=<version> -DgroupId=com.simplygeek -DartifactId=<module-name>
```

| Module holds                                   | `<group>`                              | `<archetype>`                  | Extra                                                                                                  |
| ---------------------------------------------- | -------------------------------------- | ------------------------------ | ------------------------------------------------------------------------------------------------------ |
| JavaScript actions                             | `com.vmware.pscoe.o11n.archetypes`     | `package-actions-archetype`    |                                                                                                        |
| Workflows, configurations, resources (XML)     | `com.vmware.pscoe.o11n.archetypes`     | `package-xml-archetype`        | `-DworkflowsPath=<root category>`                                                                      |
| TypeScript (what `vro-elements` was made from) | `com.vmware.pscoe.o11n.archetypes`     | `package-typescript-archetype` |                                                                                                        |
| vRA content                                    | `com.vmware.pscoe.vra-ng.archetypes`   | `package-vra-ng-archetype`     |                                                                                                        |
| Polyglot or ABX                                | `com.vmware.pscoe.polyglot.archetypes` | `package-polyglot-archetype`   | `-Druntime=nodejs -Dtype=abx` for ABX; `-Druntime=python -Dtype=vro` for an Orchestrator Python action |

`<version>` matches the PSCoE parent version in the root `pom.xml`;
the archetypes are released to Maven Central under the same version
numbers as the parent. `-Dtype` is `abx` or `vro`, and `-Druntime` is
`nodejs`, `python` or `powershell`.

After generating:

- Add the module to the `<modules>` list of the aggregator POM above
  it and check its `<parent>`.
- Delete the archetype's sample content.
- For a polyglot module, carry on with the `vro-polyglot-action`
  skill.
