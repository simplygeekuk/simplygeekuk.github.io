---
name: vro-polyglot-action
description: Use when creating, changing or removing a vRO polyglot action (Python, Node or PowerShell) or an action environment in a polyglot module. Covers the polyglot.json descriptor, the handler contract, positional inputs and every caller that has to move with them, self-contained bundles versus a shared environment, environment bundles built from the repository, version bumps, and what to verify without Maven.
---

# vRO polyglot actions

A polyglot module is a Maven module whose parent is
`com.vmware.pscoe.polyglot:polyglot-project`, with `package.json`
pulling `@vmware-pscoe/polyglotpkg` and `@vmware-pscoe/vropkg` from the
local `.m2`. Every subdirectory of `src/` holding a `polyglot.json`
becomes one vRO action in the module named by `vro.module`.
Environments live in `src/resources/environments/`. The module README
is the reference; this skill is the procedure.

Find the polyglot modules with `git ls-files "*/polyglot.json"`; the
module is the directory above `src/`. Copy from an action already in
the module being changed.

## Files of an action

| File               | Contents                                                                                                                            |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------------------- |
| `polyglot.json`    | Descriptor: runtime, entry point, inputs, output, limits                                                                            |
| `<file>.<ext>`     | The handler named by `platform.entrypoint`                                                                                          |
| `requirements.txt` | Python only. Dependencies of a self-contained bundle. Must exist even when the action uses an environment; then it is comments only |

Node actions use `package.json` in place of `requirements.txt`;
PowerShell actions have no dependency file.

## polyglot.json

```json
{
    "description": "One sentence, shown in the Orchestrator client.",
    "platform": {
        "runtime": "python:3.10",
        "environment": "",
        "action": "auto",
        "tags": [],
        "entrypoint": "handler.handler",
        "base": "out",
        "memoryLimitMb": 512,
        "timeoutSec": 900
    },
    "vro": {
        "module": "com.simplygeek.example",
        "inputs": { "name": "string" },
        "outputType": "Properties"
    },
    "files": [
        "%out",
        "!**/package.json",
        "!**/polyglot.json",
        "!**/requirements.txt"
    ]
}
```

- `platform.runtime` must be one the 4.25.0 toolchain knows:
  `python:3.7`, `python:3.10`, `node:12`, `node:14`, `node:18`,
  `node:20`, `node:22`, `powershell:7.4`,
  `powercli:11-powershell-6.2`, `powercli:12-powershell-7.1`,
  `powercli:12-powershell-7.4`, `powercli:13-powershell-7.4`.
- `platform.action` `auto` names the action after its directory. Use
  a lower camel case verb phrase, like a JavaScript action.
- `platform.entrypoint` is `<file without extension>.<function>`.
- `platform.environment` is the `id` of an environment JSON in
  `src/resources/environments/`, or empty for a self-contained bundle.
- `vro.inputs` maps input name to vRO type (`string`, `number`,
  `boolean`, `SecureString`, `Properties`, `Array/string`, ...).
  **The key order is the positional order callers use**, so treat it as
  a signature: append new inputs at the end and never reorder.
- `vro.outputType` is what the return value is mapped to.
  `Properties` for a dictionary, `Array/string` for a list, `string`
  for a scalar, `void` for none.
- Prettier formats this file: 4-space indent, CRLF.

## The handler contract

Python: `def handler(context, inputs)`. Node: `exports.handler =
(context, inputs, callback)`. PowerShell: `function Handler($context,
$inputs)`.

- `inputs` is a dictionary keyed by the input names. `SecureString`
  arrives decrypted as a plain string. Absent inputs are `None`.
- `context` carries `vcoUrl` and `getToken()` for calling the
  Orchestrator REST API back, and nothing else worth relying on.
- The return value becomes the output. A Python dict maps to
  `Properties` with the keys as property names; keep values to
  strings, numbers, booleans, lists and dicts.
- Anything written to stdout or by a logger on the root logger lands
  in the workflow's run log at INFO. Uncaught exceptions fail the
  action with the traceback as the message. Prefer returning a
  `status` and `message` for expected failures so the workflow can
  decide.
- Only the handler file is imported when the action uses an
  environment. Everything else it needs comes from that environment, so
  put the logic in a package the environment carries and keep the
  handler to validation and dispatch.

## Adding or changing an input

Inputs are positional at the call site, so a change touches every
caller in one commit. In order:

1. `vro.inputs` in `polyglot.json`, new inputs appended at the end.
2. The handler: read it from `inputs`, and any required-settings check.
3. Every caller: `grep -rn "\.<actionName>(" source/` finds the
   workflow scriptlets and JavaScript actions. Add the argument in the
   same position, with `""`, `0` or `false` where a caller has nothing
   to pass. A bound workflow attribute or input, and its `form.json`
   field, if the value comes from the form.
4. The module README's list of inputs, and `CHANGELOG.md` under
   `[Unreleased]` when a user sees the change.

Removing an input is the same list in reverse. Renaming one is a
remove and an add; do not rename in place if any caller passes it by a
`Properties` key.

## Environments

An environment is `src/resources/environments/<name>.json`, pushed
with the package. Its `id` is what actions reference, so a new
environment gets a fresh GUID and keeps it for life; `runtime`,
`memoryLimit` (bytes) and `timeout` should match the actions that use
it. `dependencies` is what Orchestrator lists.

Two ways to supply the packages:

- **Index-resolved.** JSON only. Orchestrator downloads `dependencies`
  from a package index it has registered. Nothing else to do.
- **Bundled by the build.** Add a sibling `<name>.requirements.txt`.
  `scripts/inject_environment_bundles.py`, at the repository root and
  wired into the module POM as below, pip-installs it for Linux
  x86_64 CPython 3.10 in the package phase, zips it as the bundle,
  writes the hash and re-signs. A requirements line that is a relative
  path to a Python project in this repository is built as a wheel
  first, which is how repository-owned packages reach the node without
  a package index. Every entry in `dependencies` must appear in the
  requirements file at the same version or the build fails.

An environment the build bundles is owned by the build. Do not edit it
in Orchestrator: the next push overwrites it, and a rebuild there drops
anything that came from the repository.

A module gets the bundle step from two executions in its POM, both in
the `package` phase and in this order:

1. `maven-dependency-plugin:unpack` of the signing keystore
   (`${keystoreGroupId}:${keystoreArtifactId}:${keystoreVersion}`,
   type `zip`) into `target/environment-keystore`. vropkg empties
   `target/` when it writes the package, so the keystore the parent
   unpacked earlier is gone by then.
2. `exec-maven-plugin:exec` of the script, with the `PIP_*` variables
   from the next section set on the execution:

```
python <repository root>/scripts/inject_environment_bundles.py
    --package      target/<groupId>.<artifactId>-<version>.package
    --environments src/resources/environments
    --work         out/environments
    --private-key  <keystore dir>/private_key.pem
    --certificate  <keystore dir>/cert.pem
    --key-pass     ${vroKeyPass}
```

`pom-executions.xml` in this skill directory holds both executions
and the two properties they use, ready to merge into a module POM; only
the relative path to the script changes with the module's depth. The
bundle step is an addition to Build Tools made in this repository, not
part of the polyglot archetype, so a new project also needs
`scripts/inject_environment_bundles.py` itself. The script
needs `python` with the `cryptography` package, or `openssl` on the
PATH, to re-sign the element files.

Version bumps, so Orchestrator replaces the bundle:

- requirements or `dependencies` change: bump `version` in the JSON;
- a repository-owned package changes: bump `version` in its
  `pyproject.toml` and bump the environment `version`.

## Self-contained bundles

With `platform.environment` empty, polyglotpkg installs
`requirements.txt` into the action's own bundle on the build machine.
Pure-Python packages need nothing more. A compiled package has to be
fetched for the platform Orchestrator runs on, Linux x86_64 CPython
3.10, so the module POM sets `PIP_PLATFORM=manylinux2014_x86_64`,
`PIP_PYTHON_VERSION=3.10`, `PIP_IMPLEMENTATION=cp` and
`PIP_ONLY_BINARY=:all:` on the build step, and `PIP_ABI` stays unset
so `abi3` wheels are accepted. Set the same variables by hand only
when running `npm run build` directly.

## Repository-owned packages

Logic that is more than a handler belongs in a Python package under
`source/<owner>/python/<package>/` with its own `pyproject.toml`,
`src/` and `tests/`, listed in the environment's requirements file by
relative path. It is tested with pytest and linted with ruff from that
directory, which is the only test surface a polyglot action has: the
handler itself runs only on the node.

## Verify

Never run Maven. Check:

- `python -m py_compile src/<action>/<handler>.py`;
- `python -m pytest` and `python -m ruff check src tests` in each
  repository-owned package;
- `npx prettier --check source/<module>` for the JSON files;
- `git grep -n "\.<actionName>("` shows every caller with the right
  argument count.

Give the user the build and push commands from the
`vro-maven-commands` skill, which also covers what the push replaces
and that a polyglot module cannot be pulled.

Push actions and environments before the workflows that call them, so
a workflow never runs against an action missing an input.

## Line endings

Python handlers, `polyglot.json`, `requirements.txt` and the
environment JSON already in the repository are CRLF. Keep whatever ending
a file already has when editing, and check with
`grep -c $'\r' <file>` before committing, since `sed -i` and some
heredocs rewrite them.
