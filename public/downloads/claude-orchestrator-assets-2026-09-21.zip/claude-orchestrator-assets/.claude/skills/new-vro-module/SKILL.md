---
name: new-vro-module
description: Use when creating or extending vRO JavaScript action files under source/vro-actions (com.simplygeek namespace) — new API integrations, service/client classes, object model DTOs, or standalone actions. Covers the IIFE module pattern, the 3-tier REST client lineage, System.getModule imports, Logger setup, and argument validation guards.
---

# New vRO Module

How to write vRO JavaScript action files that match this repository's
conventions exactly. Style basics (ES5 only, CRLF, 4-space indent, 80-col,
double quotes, padding lines, mandatory JSDoc) are documented in CLAUDE.md
and enforced by ESLint/Prettier — this skill covers the structural patterns.

Before writing, read the canonical exemplar for the file type you are
creating — see `exemplars.md` in this skill directory for the file map.

## 1. Decide the file type

| You need                                               | Create                       | Location                        |
| ------------------------------------------------------ | ---------------------------- | ------------------------------- |
| A new API integration                                  | A 3-tier client set (see §3) | `com/simplygeek/<api>/`         |
| A request/response body shape                          | A DTO object model           | `com/simplygeek/<api>/objects/` |
| A simple callable unit (e.g. for a workflow scriptlet) | A standalone action          | The relevant namespace dir      |

**Namespace rule:** the directory path under
`source/vro-actions/src/main/resources/com/simplygeek/` IS the vRO module
namespace. `com/simplygeek/salt/SaltJobClient.js` is imported as
`System.getModule("com.simplygeek.salt").SaltJobClient()` — note the
trailing `()`: the module export is the IIFE, which is invoked to get the
class.

## 2. Class module skeleton

Every class file (client, service, DTO) is an IIFE returning a
constructor:

```javascript
/**
 * Provides <what this module does>.
 * @returns {Any} The WidgetClient class.
 */
(function () {
    /**
     * <Class description.>
     * @class
     * @param {REST:RESTHost} restHost - The API REST host.
     * @returns {Any} An instance of the WidgetClient class.
     */
    function WidgetClient(restHost) {
        if (!restHost || System.getObjectType(restHost) !== "REST:RESTHost") {
            throw new ReferenceError(
                "restHost is required and must be of type 'REST:RESTHost'"
            );
        }

        WidgetBackendClient.call(this, restHost);

        this.log = new (System.getModule(
            "com.simplygeek.vcf.orchestrator.logging"
        ).Logger())("Action", "WidgetClient");
    }

    var WidgetBackendClient = System.getModule(
        "com.simplygeek.widget"
    ).WidgetBackendClient();

    WidgetClient.prototype = Object.create(WidgetBackendClient.prototype);
    WidgetClient.prototype.constructor = WidgetClient;

    /**
     * <Method description.>
     * @function
     * @public
     * @param {string} name - The widget name.
     * @returns {Any} The widget object.
     */

    WidgetClient.prototype.getWidgetByName = function (name) {
        if (!name || typeof name !== "string") {
            throw new ReferenceError(
                "name is required and must be of type 'string'"
            );
        }

        return this.getResourceByName("/widgets", name);
    };

    return WidgetClient;
});
```

Load-bearing details:

- The Logger idiom is fixed:
  `new (System.getModule("com.simplygeek.vcf.orchestrator.logging").Logger())("Action", "<ClassName>")`
  — second argument always equals the file/class name.
- There is a **blank line between a method's JSDoc block and its
  `prototype.method =` line** (see the skeleton above).
- Methods are grouped under banner comments like `// ## Job Templates ##`.
- Method JSDoc order: description, `@function`, `@public`/`@private`,
  `@param`s, `@returns`.

### Validation guard idioms

Guards go at the top of every constructor and method, required
arguments first. Three error types, one meaning each:

| Error            | When                                                                                                                            |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| `ReferenceError` | A required argument is missing or not of its type. One guard, one message: `"<param> is required and must be of type '<type>'"` |
| `TypeError`      | An optional argument was supplied with the wrong type                                                                           |
| `RangeError`     | The type is right but the value is not acceptable: an unsupported option, a malformed URI                                       |

An optional argument is **absent when it is `undefined` or `null`**,
and nothing else. Never decide that with truthiness: `if (x && typeof
x !== ...)` lets `false`, `0` and `""` past the type check, so a wrong
value is accepted and then dropped. Test for absence explicitly, then
validate whatever was supplied.

```javascript
// Required string (an empty string counts as missing)
if (!name || typeof name !== "string") {
    throw new ReferenceError("name is required and must be of type 'string'");
}

// Required number (zero is a valid value)
if ((!id && id !== 0) || typeof id !== "number") {
    throw new ReferenceError("id is required and must be of type 'number'");
}

// Optional: absent is undefined or null, anything else is checked
if (
    description !== undefined &&
    description !== null &&
    typeof description !== "string"
) {
    throw new TypeError("description must be of type 'string'");
}

// Optional value from a fixed set: type first, then the value
var validKinds = ["run", "check"];

if (kind !== undefined && kind !== null && typeof kind !== "string") {
    throw new TypeError("kind must be of type 'string'");
}

if (kind && validKinds.indexOf(kind) < 0) {
    throw new RangeError(
        "Unsupported kind '" +
            kind +
            "'. Supported values: " +
            validKinds.join(", ")
    );
}

// vRO plugin objects use System.getObjectType, not typeof
if (
    headers !== undefined &&
    headers !== null &&
    System.getObjectType(headers) !== "Properties"
) {
    throw new TypeError("headers must be of type 'Properties'");
}
```

Defaults come after the guards, once the type is known:

```javascript
// Optional number where zero is a real value
if (retries === undefined || retries === null) {
    retries = 5;
}

// Optional boolean defaulting to true. Only after its type guard:
// on its own this turns the string "false" into true.
throwOnNotFound = throwOnNotFound !== false;

// Optional string: "" means the same as absent, so || is safe
tagKey = tagKey || "scheduled_delete";
```

`x = x || <default>` on a number turns a supplied `0` into the
default. Use it only where zero cannot be meant, and say so in the
`@param` description.

## 3. Three-tier client lineage

New raw-REST API integrations follow the Ansible/Salt shape:

1. **`rest/HttpRestClient.js`** (existing, do not modify) — generic HTTP
   verbs, retry, logging, secret redaction.
2. **`<Api>BackendClient`** — extends HttpRestClient via
   `Object.create`. Owns auth (session headers, base URI) and generic
   helpers (`getResourceById`, `getResourceByName`, pagination). Nothing
   endpoint-specific.
3. **Typed per-resource sub-clients** (e.g. `AnsibleAWXJobClient`) —
   extend the BackendClient. All endpoint-specific methods live here.

**Hard boundary: never add API-specific methods to `HttpRestClient`, any
`*BackendClient`, or `VraPluginRestClient`. They always go in a typed
sub-client.**

For APIs accessed through the Aria Automation vRO plugin (a `VRA:Host`
rather than a `REST:RESTHost`), the base is
`vcf/automation/plugin/VraPluginRestClient.js` — same tier rules apply.

A top-level facade service (e.g. `AnsibleAutomationPlatformService`) may
compose the sub-clients and own session lifecycle
(authenticate → use → closeSession).

## 4. Object model DTOs (`<api>/objects/*.js`)

Pure specification constructors — no prototype methods, no REST calls:

- Property names use the **target API's snake_case** keys
  (`this.job_type`, `this.host_filter`).
- Required fields: validate, then assign unconditionally.
- Optional fields: validate as in §2, then **conditionally assign** so
  absent keys never appear in the payload. For a string,
  `if (kind) this.kind = kind;` is right, because the guard has already
  refused everything but a string and `""` means absent. For a number
  or a boolean it is wrong, because `0` and `false` are values: use
  `if (count !== undefined && count !== null) this.count = count;`.
- Same JSDoc and guard conventions as §2; optional params documented
  with brackets: `@param {string} [description] - ...`.

## 5. Standalone actions

The IIFE takes the action's input parameters directly and executes (no
returned class). Top-level JSDoc documents the inputs — no `@class`:

```javascript
/**
 * <What the action does.>
 * @param {string} resourceId - The resource ID.
 * @param {number} [minAgeHours] - Minimum age in hours. Default 48; 0 also takes the default.
 * @returns {Any} - A summary object.
 */
(function (resourceId, minAgeHours) {
    if (!resourceId || typeof resourceId !== "string") {
        throw new ReferenceError(
            "resourceId is required and must be of type 'string'"
        );
    }

    if (
        minAgeHours !== undefined &&
        minAgeHours !== null &&
        typeof minAgeHours !== "number"
    ) {
        throw new TypeError("minAgeHours must be of type 'number'");
    }

    // Zero is not a usable minimum age here, so it takes the default,
    // and the @param says so.
    minAgeHours = minAgeHours || 48;

    var log = new (System.getModule(
        "com.simplygeek.vcf.orchestrator.logging"
    ).Logger())("Action", "<actionFileName>");

    // ... do the work, typically delegating to a service class ...

    return { resourceId: resourceId };
});
```

Action filenames are lowerCamelCase verbs (`shutdownVM.js`,
`requestVmDeletion.js`); class files are PascalCase.

## 6. Verify

```bash
npx eslint <files>
npx prettier --check <files>
```

**Never run Maven.** When a build or test run is warranted, give the
user the command for the `vro-actions` module from
the `vro-maven-commands` skill.
