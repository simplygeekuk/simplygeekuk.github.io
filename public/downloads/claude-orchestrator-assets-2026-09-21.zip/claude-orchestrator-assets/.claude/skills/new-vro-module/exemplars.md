# Canonical exemplars

Read the matching exemplar before writing a new file — these are the
source of truth for the patterns; this skill deliberately does not
duplicate them. All paths are relative to
`source/vro-actions/src/main/resources/com/simplygeek/`.

| You are writing                                                 | Read first                                                                          |
| --------------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| Base HTTP client behavior (do not modify)                       | `rest/HttpRestClient.js`                                                            |
| A `<Api>BackendClient` (auth, session headers, generic helpers) | `salt/SaltBackendClient.js`, `ansible/AnsibleAWXBackendClient.js`                   |
| An auth client (token acquisition/release)                      | `salt/SaltAuthClient.js`, `ansible/AnsibleAWXAuthClient.js`                         |
| A typed per-resource sub-client                                 | `ansible/AnsibleAWXJobClient.js`                                                    |
| A top-level facade service (session lifecycle)                  | `ansible/AnsibleAutomationPlatformService.js`                                       |
| A plugin-based client (`VRA:Host` lineage)                      | `vcf/automation/plugin/VraPluginRestClient.js`                                      |
| An object model DTO                                             | `ansible/objects/Inventory.js`, `ansible/objects/JobTemplate.js`                    |
| A standalone action                                             | `vcenter/vm/shutdownVM.js`, `vcf/automation/plugin/deployment/requestVmDeletion.js` |
| Logger usage                                                    | `vcf/orchestrator/logging/Logger.js`                                                |
| Locking                                                         | `vcf/orchestrator/locking/LockingService.js`                                        |
| Reading config elements                                         | `vcf/orchestrator/configurations/ConfigElementService.js`                           |
| Creating a transient REST host                                  | `rest/createTransientRestHost.js`                                                   |
| String/array/date helpers                                       | `utils/StringUtils.js`, `utils/ArrayUtils.js`, `utils/DateUtils.js`                 |
