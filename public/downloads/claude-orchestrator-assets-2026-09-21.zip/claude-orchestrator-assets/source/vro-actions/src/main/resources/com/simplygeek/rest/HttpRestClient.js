/**
 * Provides a thin retrying wrapper around a vRO RESTHost. Handles request
 * creation, JSON serialisation, header injection, status-code validation,
 * and retry-on-500 behaviour.
 * @returns {Any} The HttpRestClient class.
 */
(function () {
    /**
     * REST client that issues requests against a vRO RESTHost. Each public
     * verb method (httpGet, httpPost, etc.) builds a request, executes it
     * with optional retry, and validates the response status code against
     * a caller-supplied list. Retries default to 5 attempts with 10s delay
     * and retry on HTTP 500 (`retryOn500` defaults to true; pass false to
     * disable).
     * @class
     * @param {REST:RESTHost} restHost - The HTTP REST host.
     * @param {number} [retryMaxAttempts] - Maximum retry attempts on a
     *     failed request. Defaults to 5; 0 also takes the default.
     * @param {number} [retryDelay] - Delay (in seconds) between retry
     *     attempts. Defaults to 10; 0 also takes the default.
     * @param {boolean} [retryOn500] - Whether to retry HTTP 500 responses.
     *     Defaults to true.
     * @returns {Any} An instance of the HttpRestClient class.
     */
    function HttpRestClient(
        restHost,
        retryMaxAttempts,
        retryDelay,
        retryOn500
    ) {
        if (!restHost || System.getObjectType(restHost) !== "REST:RESTHost") {
            throw new ReferenceError(
                "restHost is required and must be of type 'REST:RESTHost'"
            );
        }

        if (
            retryMaxAttempts !== undefined &&
            retryMaxAttempts !== null &&
            typeof retryMaxAttempts !== "number"
        ) {
            throw new TypeError("retryMaxAttempts must be of type 'number'");
        }

        if (
            retryDelay !== undefined &&
            retryDelay !== null &&
            typeof retryDelay !== "number"
        ) {
            throw new TypeError("retryDelay must be of type 'number'");
        }

        if (
            retryOn500 !== undefined &&
            retryOn500 !== null &&
            typeof retryOn500 !== "boolean"
        ) {
            throw new TypeError("retryOn500 must be of type 'boolean'");
        }

        this.log = new (System.getModule(
            "com.simplygeek.vcf.orchestrator.logging"
        ).Logger())("Action", "HttpRestClient");

        this.restHost = restHost;
        this.retryMaxAttempts = retryMaxAttempts || 5;
        this.retryDelay = retryDelay || 10;
        this.retryOn500 = retryOn500 !== false;

        /**
         * A method that invokes the request.
         * @function
         * @private
         * @param {string} restMethod - The request method.
         * @param {string} uri - The request uri.
         * @param {string} [acceptType] - The encoding format to accept.
         * @param {Any} content - The request content.
         * @param {string} [contentType] - The encoding for content.
         * @param {Array/number} [expectedResponseCodes] - A list of expected response codes.
         * @param {Properties} [headers] - A key/value set of headers to include in the request.
         * @returns {Any} The request response object.
         */

        this.invokeRequest = function (
            restMethod,
            uri,
            acceptType,
            content,
            contentType,
            expectedResponseCodes,
            headers
        ) {
            // eslint-disable-next-line no-useless-escape
            var uriRegex = /^[-a-zA-Z0-9()@:%_$,.~#?&\|\'\"\+\/\/=\s]*$/i;

            if (!uri || typeof uri !== "string") {
                throw new ReferenceError(
                    "uri is required and must be of type 'string'"
                );
            } else if (uri && !uri.match(uriRegex)) {
                throw new RangeError("uri not a valid URI");
            }

            if (
                acceptType !== undefined &&
                acceptType !== null &&
                typeof acceptType !== "string"
            ) {
                throw new TypeError("acceptType must be of type 'string'");
            }

            if (
                contentType !== undefined &&
                contentType !== null &&
                typeof contentType !== "string"
            ) {
                throw new TypeError("contentType must be of type 'string'");
            }

            if (
                content !== undefined &&
                content !== null &&
                typeof content !== "object"
            ) {
                throw new TypeError("content must be of type 'object'");
            }

            if (
                expectedResponseCodes !== undefined &&
                expectedResponseCodes !== null &&
                !Array.isArray(expectedResponseCodes)
            ) {
                throw new TypeError(
                    "expectedResponseCodes must be of type 'Array/number'"
                );
            } else if (
                expectedResponseCodes &&
                expectedResponseCodes.length > 0
            ) {
                expectedResponseCodes.forEach(function (code) {
                    if (typeof code !== "number") {
                        throw new TypeError(
                            "expectedResponseCodes must be of type 'Array/number'"
                        );
                    }
                });
            }

            if (
                headers !== undefined &&
                headers !== null &&
                System.getObjectType(headers) !== "Properties"
            ) {
                throw new TypeError("headers must be of type 'Properties'");
            }

            var response;
            var statusCode;
            var retryAttempt = 1;
            var requestSummary = restMethod + " " + uri;
            var lastStatusCode;
            var lastResponseBody;

            // Default to status code '200' if no expected status codes have been defined.
            if (
                !expectedResponseCodes ||
                (Array.isArray(expectedResponseCodes) &&
                    expectedResponseCodes.length < 1)
            ) {
                expectedResponseCodes = [200, 201, 204];
            }

            this.createRequest(
                restMethod,
                uri,
                acceptType,
                content,
                contentType,
                headers
            );

            this.log.debug("Invoking request...");
            this.log.debug("URL: " + this.request.fullUrl);
            this.log.debug("Method: " + restMethod);

            if (content) {
                var regex = new RegExp("(password|secret|refreshToken)", "i");
                var contentString = JSON.stringify(content);
                var matches = contentString.match(regex);

                if (matches) {
                    content[matches[1]] = "*******";
                    contentString = JSON.stringify(content);
                }

                this.log.debug("Content: " + contentString);
            }

            do {
                try {
                    response = this.request.execute();
                    statusCode = response.statusCode;
                    lastStatusCode = statusCode;
                    lastResponseBody = response.contentAsString;

                    if (statusCode === 500 && this.retryOn500) {
                        response = null;
                        throw new Error(lastResponseBody);
                    }
                } catch (e) {
                    this.log.warn(
                        requestSummary +
                            " failed: " +
                            e +
                            " (retry " +
                            retryAttempt +
                            "/" +
                            this.retryMaxAttempts +
                            ")"
                    );

                    if (retryAttempt < this.retryMaxAttempts) {
                        System.sleep(this.retryDelay * 1000);
                    }
                }

                retryAttempt++;
            } while (!response && retryAttempt <= this.retryMaxAttempts);

            if (!response) {
                throw new Error(
                    requestSummary +
                        " failed after " +
                        this.retryMaxAttempts.toString() +
                        " attempts" +
                        (lastStatusCode
                            ? "; last status " +
                              lastStatusCode +
                              " body: " +
                              lastResponseBody
                            : "")
                );
            }

            if (expectedResponseCodes.indexOf(statusCode) > -1) {
                this.log.debug(
                    "Request completed successfully with status: " + statusCode
                );
            } else {
                throw new Error(
                    requestSummary +
                        " returned " +
                        statusCode +
                        ", expected one of [" +
                        expectedResponseCodes.join(", ") +
                        "]: " +
                        response.contentAsString
                );
            }

            return response;
        };

        /**
         * A function that creates the request.
         * @function
         * @private
         * @param {string} restMethod - The request method.
         * @param {string} uri - The request uri.
         * @param {string} [acceptType] - The encoding format to accept.
         * @param {Any} [content] - The request content.
         * @param {string} [contentType] - The encoding for content.
         * @param {Properties} [headers] - A key/value set of headers to include in the request.
         * @returns {Any} The request response object.
         */

        this.createRequest = function (
            restMethod,
            uri,
            acceptType,
            content,
            contentType,
            headers
        ) {
            // Perform URL encoding.
            if (contentType === "application/x-www-form-urlencoded") {
                this.log.debug(
                    "x-www-form-urlencoded will be used for URL encoding."
                );
            } else {
                if (uri.indexOf("%") > -1) {
                    this.log.debug(
                        "Possible encoding detected in URI, encoder will not be used."
                    );
                } else {
                    this.log.debug("Performing URL encoding.");
                    uri = encodeURI(uri);

                    this.log.debug("Encoded URL: " + uri);
                }
            }

            // Set default media types if not defined.
            this.acceptType = acceptType || "application/json";
            this.contentType = contentType || this.acceptType;

            // Create request
            this.log.debug("Creating REST request...");
            this.log.debug(
                "Setting Content-Type to '" + this.contentType + "'"
            );

            if (!content) {
                this.request = this.restHost.createRequest(restMethod, uri);
                this.request.contentType = this.contentType;
            } else {
                if (contentType === "application/x-www-form-urlencoded") {
                    this.request = this.restHost.createRequest(
                        restMethod,
                        uri,
                        this.xwwwformurlencoder(content)
                    );
                    this.request.contentType = this.contentType;
                } else {
                    this.request = this.restHost.createRequest(
                        restMethod,
                        uri,
                        JSON.stringify(content)
                    );
                    this.request.contentType = this.contentType;
                }
            }

            this.log.debug("Setting headers...");
            this.setHeaders(headers);
        };

        /**
         * Injects Accept and Content-Type onto the current request, then
         * applies any caller-supplied custom headers from a Properties
         * object. Invoked by createRequest.
         * @function
         * @private
         * @param {Properties} [headers] - Caller-supplied headers (e.g. an
         *     Authorization Bearer token).
         */

        this.setHeaders = function (headers) {
            this.log.debug("Adding Header: Accept: " + this.acceptType);
            this.request.setHeader("Accept", this.acceptType);
            this.log.debug("Adding Header: Content-Type: " + this.contentType);
            this.request.setHeader("Content-Type", this.contentType);
            if (headers) {
                headers.keys.forEach(function (headerKey) {
                    var headerValue = headers.get(headerKey);

                    this.log.debug(
                        "Adding Header: '" +
                            headerKey +
                            ": " +
                            headerValue +
                            "'"
                    );
                    this.request.setHeader(headerKey, headerValue);
                }, this);
            }
        };

        /**
         * A function that converts a JSON body to a form-url-encoded string
         * @function
         * @private
         * @param {Any} [content] - The request content.
         * @returns {string} The form url encoded string.
         */

        this.xwwwformurlencoder = function (content) {
            this.log.debug("Performing Form URL Encoding");
            var contentUrlEncoded = "";
            var keys = Object.keys(content);

            for (var i = 0; i < keys.length; i++) {
                var key = keys[i];
                var value;

                if (
                    key.toLowerCase() === "password" ||
                    key.toLowerCase() === "secret"
                ) {
                    value = content[keys[i]];
                } else {
                    value = encodeURIComponent(content[keys[i]]);
                }

                contentUrlEncoded += encodeURIComponent(key) + "=" + value;
                if (i < keys.length - 1) contentUrlEncoded += "&";
            }

            return contentUrlEncoded;
        };
    }

    /**
     * Performs a GET against the given URI. No body is sent. Returns the
     * raw response object; callers parse the body themselves.
     * @function
     * @public
     * @param {string} uri - The request URI.
     * @param {string} [acceptType] - Accept media type. Defaults to
     *     'application/json'.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [200, 201, 204].
     * @param {Properties} [headers] - Caller-supplied headers (e.g.
     *     Authorization).
     * @returns {Any} The raw response object.
     */

    HttpRestClient.prototype.httpGet = function (
        uri,
        acceptType,
        expectedResponseCodes,
        headers
    ) {
        var response = this.invokeRequest(
            "GET",
            uri,
            acceptType,
            null,
            null,
            expectedResponseCodes,
            headers
        );

        return response;
    };

    /**
     * Performs a POST against the given URI. Content is JSON-serialised by
     * default; pass contentType 'application/x-www-form-urlencoded' to send
     * a form-encoded body instead. If content is omitted, an empty body
     * `{}` is sent.
     * @function
     * @public
     * @param {string} uri - The request URI.
     * @param {string} [acceptType] - Accept media type. Defaults to
     *     'application/json'.
     * @param {Any} [content] - Request body (object for JSON, object for
     *     form-url-encoded).
     * @param {string} [contentType] - Content-Type header. Defaults to
     *     acceptType.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [200, 201, 204].
     * @param {Properties} [headers] - Caller-supplied headers.
     * @returns {Any} The raw response object.
     */

    HttpRestClient.prototype.httpPost = function (
        uri,
        acceptType,
        content,
        contentType,
        expectedResponseCodes,
        headers
    ) {
        content = content || {};

        var response = this.invokeRequest(
            "POST",
            uri,
            acceptType,
            content,
            contentType,
            expectedResponseCodes,
            headers
        );

        return response;
    };

    /**
     * Performs a PUT against the given URI for a full resource replacement.
     * Content is required and JSON-serialised by default.
     * @function
     * @public
     * @param {string} uri - The request URI.
     * @param {string} [acceptType] - Accept media type. Defaults to
     *     'application/json'.
     * @param {Any} content - Full replacement body.
     * @param {string} [contentType] - Content-Type header. Defaults to
     *     acceptType.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [200, 201, 204].
     * @param {Properties} [headers] - Caller-supplied headers.
     * @returns {Any} The raw response object.
     */

    HttpRestClient.prototype.httpPut = function (
        uri,
        acceptType,
        content,
        contentType,
        expectedResponseCodes,
        headers
    ) {
        var response = this.invokeRequest(
            "PUT",
            uri,
            acceptType,
            content,
            contentType,
            expectedResponseCodes,
            headers
        );

        return response;
    };

    /**
     * Performs a PATCH against the given URI for a partial resource update.
     * Content is required and JSON-serialised; only the supplied fields are
     * sent.
     * @function
     * @public
     * @param {string} uri - The request URI.
     * @param {string} [acceptType] - Accept media type. Defaults to
     *     'application/json'.
     * @param {Any} content - Object containing the fields to update.
     * @param {string} [contentType] - Content-Type header. Defaults to
     *     acceptType.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [200, 201, 204].
     * @param {Properties} [headers] - Caller-supplied headers.
     * @returns {Any} The raw response object.
     */

    HttpRestClient.prototype.httpPatch = function (
        uri,
        acceptType,
        content,
        contentType,
        expectedResponseCodes,
        headers
    ) {
        var response = this.invokeRequest(
            "PATCH",
            uri,
            acceptType,
            content,
            contentType,
            expectedResponseCodes,
            headers
        );

        return response;
    };

    /**
     * Performs a DELETE against the given URI. No body is sent.
     * @function
     * @public
     * @param {string} uri - The request URI.
     * @param {string} [acceptType] - Accept media type. Defaults to
     *     'application/json'.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [200, 201, 204].
     * @param {Properties} [headers] - Caller-supplied headers.
     * @returns {Any} The raw response object.
     */

    HttpRestClient.prototype.httpDelete = function (
        uri,
        acceptType,
        expectedResponseCodes,
        headers
    ) {
        var response = this.invokeRequest(
            "DELETE",
            uri,
            acceptType,
            null,
            null,
            expectedResponseCodes,
            headers
        );

        return response;
    };

    /**
     * Performs a HEAD against the given URI to retrieve response headers
     * and status without a body. Useful for existence checks and
     * conditional-request handling.
     * @function
     * @public
     * @param {string} uri - The request URI.
     * @param {string} [acceptType] - Accept media type. Defaults to
     *     'application/json'.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [200, 201, 204].
     * @param {Properties} [headers] - Caller-supplied headers.
     * @returns {Any} The raw response object.
     */

    HttpRestClient.prototype.httpHead = function (
        uri,
        acceptType,
        expectedResponseCodes,
        headers
    ) {
        var response = this.invokeRequest(
            "HEAD",
            uri,
            acceptType,
            null,
            null,
            expectedResponseCodes,
            headers
        );

        return response;
    };

    return HttpRestClient;
});
