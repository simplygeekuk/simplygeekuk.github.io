/**
 * Provides a base HTTP client for the Aria Automation Config (SaltStack
 * Config / SSC) API. Carries HTTP Basic auth (on the supplied RESTHost) and
 * transparently manages the short-lived xsrf token required by the SSC RPC
 * endpoint. Exposes an rpc() helper that wraps SSC's JSON-RPC /rpc endpoint.
 * @returns {Any} The SaltBackendClient class.
 */
(function () {
    /**
     * Base HTTP client for the SSC RPC API, used by the typed sub-clients
     * (Target, File, Job). SSC's API is RPC-shaped (POST /rpc with
     * {resource, method, kwarg}). Authentication is HTTP Basic (configured
     * on the RESTHost by SaltAuthClient) plus an xsrf token obtained from a
     * GET /version round-trip and sent as the X-Xsrftoken header. The token
     * is short-lived and refreshed lazily before each call; if the server
     * does not issue one (xsrf disabled) the header is simply omitted.
     * @class
     * @param {REST:RESTHost} restHost - The SSC HTTP REST host, already
     *     carrying HTTP Basic authentication.
     * @returns {Any} An instance of the SaltBackendClient class.
     */
    function SaltBackendClient(restHost) {
        if (!restHost || System.getObjectType(restHost) !== "REST:RESTHost") {
            throw new ReferenceError(
                "restHost is required and must be of type 'REST:RESTHost'"
            );
        }

        this.mediaType = "application/json";
        this.rpcUri = "/rpc";
        this.versionUri = "/version";
        this.sessionHeaders = new Properties();
        this.restHost = restHost;
        this._xsrfToken = null;
        this._xsrfExpiry = 0;
        // The reference SaltStackConfigClient assumes a 60s token lifetime;
        // 50s leaves a margin against a token expiring mid-request.
        this._xsrfTokenTtlSeconds = 50;

        HttpRestClient.call(this, this.restHost);

        this.log = new (System.getModule(
            "com.simplygeek.vcf.orchestrator.logging"
        ).Logger())("Action", "SaltBackendClient");
    }

    var HttpRestClient = System.getModule(
        "com.simplygeek.rest"
    ).HttpRestClient();

    SaltBackendClient.prototype = Object.create(HttpRestClient.prototype);
    SaltBackendClient.prototype.constructor = SaltBackendClient;

    // ###############
    // ## RPC Helper #
    // ###############

    /**
     * Invokes an SSC RPC call by POSTing {resource, method, kwarg} to the
     * /rpc endpoint. Ensures a valid xsrf token first, parses the JSON
     * response and unwraps SSC's envelope: if the response carries a
     * non-empty `error`, throws Error with the serialised error payload;
     * otherwise returns the `ret` field (or the full body if no `ret` is
     * present).
     * @function
     * @public
     * @param {string} resource - The SSC RPC resource (e.g. "cmd", "ret",
     *     "minions", "fs").
     * @param {string} method - The RPC method name on that resource.
     * @param {Any} [kwarg] - The RPC keyword arguments object.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [200].
     * @returns {Any} The unwrapped `ret` payload from the SSC response.
     */

    SaltBackendClient.prototype.rpc = function (
        resource,
        method,
        kwarg,
        expectedResponseCodes
    ) {
        if (!resource || typeof resource !== "string") {
            throw new ReferenceError(
                "resource is required and must be of type 'string'"
            );
        }

        if (!method || typeof method !== "string") {
            throw new ReferenceError(
                "method is required and must be of type 'string'"
            );
        }

        if (
            kwarg !== undefined &&
            kwarg !== null &&
            typeof kwarg !== "object"
        ) {
            throw new TypeError("kwarg must be of type 'object'");
        }

        if (
            !expectedResponseCodes ||
            (Array.isArray(expectedResponseCodes) &&
                expectedResponseCodes.length < 1)
        ) {
            expectedResponseCodes = [200];
        }

        this._ensureXsrfToken();

        var content = {
            resource: resource,
            method: method,
            kwarg: kwarg || {},
        };

        this.log.debug("RPC call '" + resource + "." + method + "'");

        var response = this.httpPost(
            this.rpcUri,
            this.mediaType,
            content,
            this.mediaType,
            expectedResponseCodes,
            this.sessionHeaders
        );
        var responseContent = JSON.parse(response.contentAsString);

        if (responseContent && responseContent.error) {
            throw new Error(
                "SSC RPC '" +
                    resource +
                    "." +
                    method +
                    "' failed: " +
                    JSON.stringify(responseContent.error)
            );
        }

        if (
            responseContent &&
            responseContent.warnings &&
            responseContent.warnings.length > 0
        ) {
            this.log.debug(
                "SSC RPC '" +
                    resource +
                    "." +
                    method +
                    "' warnings: " +
                    JSON.stringify(responseContent.warnings)
            );
        }

        if (
            responseContent &&
            Object.prototype.hasOwnProperty.call(responseContent, "ret")
        ) {
            return responseContent.ret;
        }

        return responseContent;
    };

    // ##########################
    // ## XSRF Token Lifecycle ##
    // ##########################

    /**
     * Ensures a valid xsrf token is present in the session headers. If the
     * cached token is still within its TTL, returns immediately. Otherwise
     * performs a GET /version and obtains the token from the X-Xsrftoken
     * response header (or, failing that, the `_xsrf` Set-Cookie value).
     *
     * Tornado's xsrf check requires BOTH the X-Xsrftoken request header and
     * a matching `_xsrf` cookie, so when a token is found it is applied to
     * sessionHeaders as both the X-Xsrftoken header and a `Cookie: _xsrf=`
     * header. If no token is issued (xsrf disabled) both are left absent and
     * calls proceed on HTTP Basic auth alone.
     * @function
     * @private
     */

    SaltBackendClient.prototype._ensureXsrfToken = function () {
        if (this._xsrfToken && Date.now() < this._xsrfExpiry) {
            return;
        }

        this.log.debug("Obtaining xsrf token via GET " + this.versionUri);

        var response = this.httpGet(
            this.versionUri,
            this.mediaType,
            [200],
            null
        );
        var headers = response.getAllHeaders();
        var headerToken = null;
        var setCookie = null;
        var headerNames = [];

        if (headers) {
            headers.keys.forEach(function (headerKey) {
                headerNames.push(headerKey);

                var lowerKey = headerKey.toLowerCase();

                if (lowerKey === "x-xsrftoken") {
                    headerToken = headers.get(headerKey);
                } else if (lowerKey === "set-cookie") {
                    setCookie = headers.get(headerKey);
                }
            });
        }

        var token = headerToken;

        // Fall back to the `_xsrf` value from Set-Cookie when the server did
        // not echo an X-Xsrftoken response header.
        if (!token && setCookie) {
            var marker = "_xsrf=";
            var markerIndex = setCookie.indexOf(marker);

            if (markerIndex >= 0) {
                var cookieRest = setCookie.substring(
                    markerIndex + marker.length
                );
                var semicolonIndex = cookieRest.indexOf(";");

                token =
                    semicolonIndex >= 0
                        ? cookieRest.substring(0, semicolonIndex)
                        : cookieRest;
            }
        }

        if (token) {
            this._xsrfToken = token;
            this._xsrfExpiry = Date.now() + this._xsrfTokenTtlSeconds * 1000;
            this.sessionHeaders.put("X-Xsrftoken", token);
            this.sessionHeaders.put("Cookie", "_xsrf=" + token);
            this.log.debug(
                "xsrf token obtained; X-Xsrftoken and Cookie headers applied"
            );
        } else {
            this._xsrfToken = null;
            this._xsrfExpiry = 0;
            this.sessionHeaders.remove("X-Xsrftoken");
            this.sessionHeaders.remove("Cookie");
            this.log.warn(
                "No xsrf token from GET " +
                    this.versionUri +
                    " (no X-Xsrftoken header or _xsrf cookie). Response " +
                    "headers seen: " +
                    headerNames.join(", ")
            );
        }
    };

    return SaltBackendClient;
});
