/**
 * Requests the deletion of a VM resource, enforcing a minimum age.
 * This action decides what happens and deletes nothing itself: every
 * route ends in a day-2 delete action, which the platform rejects
 * while this request is open, so the calling workflow starts the
 * matching deferred workflow asynchronously through its own workflow
 * element and that run retries until the deployment is free.
 *
 * A VM past the minimum age is reported for immediate deletion, either
 * as deleteMachine ('VM - Deferred Delete' removes the machine with
 * the deployment's day-2 delete action) or, when it is the last live
 * machine of its deployment, as deleteDeployment
 * ('Deployment - Deferred Delete' removes the whole deployment rather
 * than leave an empty shell). A VM younger than the minimum age is
 * marked with a scheduled-deletion tag instead, and the scheduled
 * deletion workflow is scheduled to run the minimum age's worth of
 * hours after the request, so the VM is always past the minimum age
 * when it fires and every deferred deletion has a full cancellation
 * window. A scheduled deletion can be cancelled with cancelVmDeletion,
 * which removes the tag (the scheduled workflow then does nothing when
 * it fires).
 * @param {string} resourceId - The VM resource ID.
 * @param {string} scheduledWorkflowId - The ID of the scheduled deletion workflow (used for deferred deletions).
 * @param {number} [minAgeHours] - The minimum age (in hours) a VM must reach before it is deleted. Default 48; 0 also takes the default.
 * @param {string} [tagKey] - The scheduled-deletion tag key. Default "scheduled_delete".
 * @param {number} [timeoutSeconds] - Timeout waiting for each request. Default 300; 0 also takes the default.
 * @returns {Any} - A summary object describing what was decided. deleteDeployment and deleteMachine tell the caller which deferred workflow to start; deploymentId and resourceId are its inputs.
 */
(function (
    resourceId,
    scheduledWorkflowId,
    minAgeHours,
    tagKey,
    timeoutSeconds
) {
    if (!resourceId || typeof resourceId !== "string") {
        throw new ReferenceError(
            "resourceId is required and must " + "be of type 'string'"
        );
    }

    if (!scheduledWorkflowId || typeof scheduledWorkflowId !== "string") {
        throw new ReferenceError(
            "scheduledWorkflowId is required and must " + "be of type 'string'"
        );
    }

    if (
        minAgeHours !== undefined &&
        minAgeHours !== null &&
        typeof minAgeHours !== "number"
    ) {
        throw new TypeError("minAgeHours must be of type 'number'");
    }

    if (tagKey !== undefined && tagKey !== null && typeof tagKey !== "string") {
        throw new TypeError("tagKey must be of type 'string'");
    }

    if (
        timeoutSeconds !== undefined &&
        timeoutSeconds !== null &&
        typeof timeoutSeconds !== "number"
    ) {
        throw new TypeError("timeoutSeconds must be of type 'number'");
    }

    /**
     * Parses an ISO 8601 UTC datetime string to epoch milliseconds.
     * Tolerates any fractional-second precision (the platform returns
     * microseconds, which Date.parse does not reliably handle).
     * @param {string} isoString - The ISO 8601 datetime string.
     * @returns {number} The epoch milliseconds, or NaN if unparsable.
     */
    function parseIsoDate(isoString) {
        var match =
            /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?Z?$/.exec(
                isoString || ""
            );

        if (!match) {
            return NaN;
        }

        var millis = match[7]
            ? parseInt((match[7] + "000").substring(0, 3), 10)
            : 0;

        return Date.UTC(
            parseInt(match[1], 10),
            parseInt(match[2], 10) - 1,
            parseInt(match[3], 10),
            parseInt(match[4], 10),
            parseInt(match[5], 10),
            parseInt(match[6], 10),
            millis
        );
    }

    var log = new (System.getModule(
        "com.simplygeek.vcf.orchestrator.logging"
    ).Logger())("Action", "requestVmDeletion");
    var vraHost = System.getModule(
        "com.simplygeek.vcf.automation.plugin"
    ).getDefaultVraHost();
    var deploymentService = new (System.getModule(
        "com.simplygeek.vcf.automation.plugin.deployment"
    ).VraPluginDeploymentService())(vraHost);
    var machineService = new (System.getModule(
        "com.simplygeek.vcf.automation.plugin.machine"
    ).VraPluginMachineService())(vraHost);
    var deletionDatePropertyKey = "scheduledDeletionDate";
    var taskIdPropertyKey = "scheduledDeletionTaskId";

    minAgeHours = minAgeHours || 48;
    tagKey = tagKey || "scheduled_delete";
    timeoutSeconds = timeoutSeconds || 300;

    var resource = deploymentService.getResourceById(resourceId);
    // Passed to the deferred workflows, which run after this one.
    var deploymentId = resource.deploymentId || null;

    if (!resource.createdAt) {
        throw new Error(
            "Resource '" +
                resourceId +
                "' has no createdAt timestamp, unable to determine its age"
        );
    }

    var createdMillis = parseIsoDate(resource.createdAt);

    if (isNaN(createdMillis)) {
        throw new Error(
            "Unable to parse createdAt timestamp '" +
                resource.createdAt +
                "' of resource '" +
                resourceId +
                "'"
        );
    }

    var nowMillis = new Date().getTime();
    var ageThresholdMillis = createdMillis + minAgeHours * 3600000;

    if (ageThresholdMillis <= nowMillis) {
        log.info(
            "VM '" +
                resource.name +
                "' (" +
                resourceId +
                ") is older than " +
                minAgeHours +
                " hours, handing the deletion to the deferred workflow"
        );

        // Whether anything else live remains decides what gets
        // deleted: the last machine takes its deployment with it,
        // otherwise only the machine goes. Best-effort - an unreadable
        // resource list falls back to deleting the machine alone,
        // which leaves an empty deployment the deployment flow can
        // remove.
        var isLastMachine = false;

        if (deploymentId) {
            try {
                isLastMachine =
                    deploymentService.countLiveMachineResources(
                        deploymentId,
                        resourceId
                    ) === 0;
            } catch (e) {
                log.warn(
                    "Unable to tell whether VM '" +
                        resourceId +
                        "' is the last machine of deployment '" +
                        deploymentId +
                        "', deleting the machine on its own: " +
                        e
                );
            }
        }

        log.info(
            isLastMachine
                ? "VM '" +
                      resourceId +
                      "' is the last live machine of deployment '" +
                      deploymentId +
                      "', the deployment is to be deleted with it"
                : "VM '" + resourceId + "' is to be deleted on its own"
        );

        // Nothing is deleted here. Both routes end in a day-2 delete
        // action, which the platform rejects while this request is
        // open, so the caller starts the matching deferred workflow
        // asynchronously and that run retries until the deployment is
        // free again.
        return {
            resourceId: resourceId,
            deploymentId: deploymentId,
            deleted: false,
            scheduled: false,
            alreadyScheduled: false,
            fireMillis: null,
            taskId: null,
            deletionDateStamped: false,
            deleteDeployment: isLastMachine,
            deleteMachine: !isLastMachine,
        };
    }

    // The VM is younger than the minimum age - defer the deletion.
    var currentTags = (resource.properties && resource.properties.tags) || [];
    var alreadyScheduled = currentTags.some(function (tag) {
        return tag.key === tagKey;
    });

    if (alreadyScheduled) {
        log.info(
            "VM '" +
                resourceId +
                "' already has a scheduled deletion (tag '" +
                tagKey +
                "' is present), nothing to do"
        );

        return {
            resourceId: resourceId,
            deploymentId: deploymentId,
            deleted: false,
            scheduled: false,
            alreadyScheduled: true,
            fireMillis: null,
            taskId: null,
            deletionDateStamped: false,
            deleteDeployment: false,
            deleteMachine: false,
        };
    }

    var scheduledWorkflow = Server.getWorkflowWithId(scheduledWorkflowId);

    if (!scheduledWorkflow) {
        throw new Error(
            "No workflow found with ID '" +
                scheduledWorkflowId +
                "', unable to schedule the deferred deletion"
        );
    }

    // The deferred deletion runs the minimum age's worth of hours after
    // the request (not at the moment the VM reaches the minimum age):
    // the VM is always past the minimum age when the task fires, and
    // the user always has the full window to cancel.
    var fireMillis = nowMillis + minAgeHours * 3600000;
    var fireDate = new Date(fireMillis);
    // Tag values cannot safely contain colons, so the (informational)
    // fire time is written as UTC with dashes, e.g. 2026-07-26T09-15-27Z.
    var fireDateTagValue = fireDate
        .toISOString()
        .replace(/\.\d+Z$/, "Z")
        .replace(/:/g, "-");

    log.info(
        "VM '" +
            resource.name +
            "' (" +
            resourceId +
            ") is younger than " +
            minAgeHours +
            " hours, scheduling deletion for " +
            fireDate.toISOString()
    );

    // Schedule the task first, then mark the VM. If tagging fails, the
    // orphaned task finds no tag when it fires and does nothing.
    var workflowInputs = new Properties();

    // Plain string values only - exotic value types (and booleans)
    // stored in a task can fail to decode when it fires.
    // Whether the VM is the last machine of its deployment is decided
    // when the task fires, not now - the deployment can gain or lose
    // machines during the cancellation window.
    workflowInputs.put("resourceId", String(resourceId));
    workflowInputs.put("tagKey", String(tagKey));

    var task = scheduledWorkflow.schedule(workflowInputs, fireDate);

    try {
        deploymentService.applyTagToResource(
            resourceId,
            tagKey,
            fireDateTagValue,
            false,
            true,
            10,
            timeoutSeconds
        );
    } catch (e) {
        throw new Error(
            "Failed to apply the scheduled-deletion tag to VM '" +
                resourceId +
                "'. The deletion is NOT scheduled (the created task " +
                "will find no tag and do nothing). If the platform " +
                "reports 'Action is not supported based on the current " +
                "state', check for an in-progress request on the VM or " +
                "its deployment, or an expired deployment lease. " +
                "Original error: " +
                e
        );
    }

    // Stamp the deletion date on the machine's custom properties for
    // visibility. Best-effort: the deletion is already scheduled, so a
    // stamping failure must not fail the request.
    var deletionDateStamped = false;

    try {
        var machineProperties = {};

        machineProperties[deletionDatePropertyKey] = fireDate.toISOString();

        // Recording the task ID lets the cancel action remove the
        // scheduled task instead of leaving it to fire and no-op.
        if (task && task.id) {
            machineProperties[taskIdPropertyKey] = task.id;
        }

        machineService.updateMachineCustomProperties(
            resourceId,
            machineProperties
        );
        deletionDateStamped = true;
    } catch (e) {
        log.warn(
            "Unable to stamp the '" +
                deletionDatePropertyKey +
                "' custom property on machine '" +
                resourceId +
                "': " +
                e
        );
    }

    log.info(
        "Deletion of VM '" +
            resourceId +
            "' scheduled for " +
            fireDate.toISOString()
    );

    return {
        resourceId: resourceId,
        deploymentId: deploymentId,
        deleted: false,
        scheduled: true,
        alreadyScheduled: false,
        fireMillis: fireMillis,
        taskId: task ? task.id : null,
        deletionDateStamped: deletionDateStamped,
        deleteDeployment: false,
        deleteMachine: false,
    };
});
