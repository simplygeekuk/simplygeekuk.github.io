/**
 * Provides an Ansible AWX Inventory specification object for use with
 * AnsibleAWXInventoryClient.createInventory / .updateInventory.
 * @returns {Any} The Inventory class.
 */
(function () {
    /**
     * Specification for an AWX Inventory (a collection of hosts and groups
     * that jobs target). Inventories may be statically populated, smart
     * (host-filter based), or fed by inventory sources.
     * @class
     * @param {string} name - The inventory name.
     * @param {number} organizationId - The owning organization ID.
     * @param {string} [kind] - 'smart' to make this a smart inventory; omit
     *     for a normal inventory.
     * @param {string} [hostFilter] - Host filter expression (smart
     *     inventories only).
     * @param {string} [variables] - Inventory-level variables as JSON or
     *     YAML string.
     * @param {string} [description] - Optional description.
     * @returns {Any} An instance of the Inventory class.
     */
    function Inventory(
        name,
        organizationId,
        kind,
        hostFilter,
        variables,
        description
    ) {
        var validKinds = ["smart"];

        if (!name || typeof name !== "string") {
            throw new ReferenceError(
                "name is required and must be of type 'string'"
            );
        }

        if (
            (!organizationId && organizationId !== 0) ||
            typeof organizationId !== "number"
        ) {
            throw new ReferenceError(
                "organizationId is required and must be of type 'number'"
            );
        }

        if (kind !== undefined && kind !== null && typeof kind !== "string") {
            throw new TypeError("kind must be of type 'string'");
        }

        if (kind && validKinds.indexOf(kind) < 0) {
            throw new RangeError(
                "Unsupported kind '" +
                    kind +
                    "'. Supported values: " +
                    validKinds.join(", ")
            );
        }

        if (
            hostFilter !== undefined &&
            hostFilter !== null &&
            typeof hostFilter !== "string"
        ) {
            throw new TypeError("hostFilter must be of type 'string'");
        }

        if (
            variables !== undefined &&
            variables !== null &&
            typeof variables !== "string"
        ) {
            throw new TypeError("variables must be of type 'string'");
        }

        if (
            description !== undefined &&
            description !== null &&
            typeof description !== "string"
        ) {
            throw new TypeError("description must be of type 'string'");
        }

        this.name = name;
        this.organization = organizationId;

        if (kind) this.kind = kind;

        if (hostFilter) this.host_filter = hostFilter;

        if (variables) this.variables = variables;

        if (description) this.description = description;
    }

    return Inventory;
});
