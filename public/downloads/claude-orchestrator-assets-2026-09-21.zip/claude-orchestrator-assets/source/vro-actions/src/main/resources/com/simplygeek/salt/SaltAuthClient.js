/**
 * Provides an Aria Automation Config (SSC) authentication helper. SSC's RPC
 * API authenticates with HTTP Basic credentials; this client produces a
 * transient RESTHost carrying those credentials for the other Salt clients
 * to use. The short-lived xsrf token is handled separately and transparently
 * by SaltBackendClient.
 * @returns {Any} The SaltAuthClient class.
 */
(function () {
    /**
     * Thin helper that builds a HTTP Basic-authenticated transient clone of
     * the supplied RESTHost. It is the only Salt client that takes raw
     * credentials. There is no login token or server-side session — the
     * xsrf token lifecycle lives in SaltBackendClient — so authenticate()
     * makes no network call and closeSession() simply drops the host.
     * @class
     * @param {REST:RESTHost} restHost - The SSC HTTP REST host.
     * @param {string} username - The SSC username.
     * @param {string} password - The SSC password.
     * @returns {Any} An instance of the SaltAuthClient class.
     */
    function SaltAuthClient(restHost, username, password) {
        if (!restHost || System.getObjectType(restHost) !== "REST:RESTHost") {
            throw new ReferenceError(
                "restHost is required and must be of type 'REST:RESTHost'"
            );
        }

        if (!username || typeof username !== "string") {
            throw new ReferenceError(
                "username is required and must be of type 'string'"
            );
        }

        if (!password || typeof password !== "string") {
            throw new ReferenceError(
                "password is required and must be of type 'string'"
            );
        }

        this.restHost = restHost;
        this.username = username;
        this.password = password;
        this.authedHost = null;

        this.log = new (System.getModule(
            "com.simplygeek.vcf.orchestrator.logging"
        ).Logger())("Action", "SaltAuthClient");
    }

    // ####################
    // ## Authentication ##
    // ####################

    /**
     * Builds a transient clone of the supplied RESTHost and sets HTTP Basic
     * authentication on it from the stored credentials, so the caller's host
     * is never mutated. No network call is made — the xsrf token round-trip
     * is performed lazily by SaltBackendClient on first use.
     * @function
     * @public
     * @returns {REST:RESTHost} The Basic-authenticated transient REST host.
     */

    SaltAuthClient.prototype.authenticate = function () {
        var basicAuth = RESTAuthenticationManager.createAuthentication(
            "Basic",
            ["Shared Session", this.username, this.password]
        );
        var transientHost = RESTHostManager.createTransientHostFrom(
            this.restHost
        );

        transientHost.authentication = basicAuth;
        this.authedHost = transientHost;

        this.log.debug("Basic-authenticated transient host created");

        return this.authedHost;
    };

    /**
     * Clears the in-memory authenticated host. Idempotent and safe to call
     * before authenticate() or twice in succession (e.g. from a finally
     * block).
     * @function
     * @public
     */

    SaltAuthClient.prototype.closeSession = function () {
        this.authedHost = null;
    };

    /**
     * Convenience wrapper that calls authenticate(), invokes the supplied
     * callback with the resulting Basic-authenticated RESTHost, and
     * guarantees closeSession() runs in a finally block — even if the
     * callback throws. The callback's return value is propagated as
     * withSession's result.
     * @function
     * @public
     * @param {function(REST:RESTHost): Any} callback - Invoked with the
     *     authenticated host; its return value is returned from withSession.
     * @returns {Any} The value returned by the callback.
     */

    SaltAuthClient.prototype.withSession = function (callback) {
        if (typeof callback !== "function") {
            throw new TypeError("callback must be of type 'function'");
        }

        var authedHost = this.authenticate();

        try {
            return callback(authedHost);
        } finally {
            this.closeSession();
        }
    };

    return SaltAuthClient;
});
