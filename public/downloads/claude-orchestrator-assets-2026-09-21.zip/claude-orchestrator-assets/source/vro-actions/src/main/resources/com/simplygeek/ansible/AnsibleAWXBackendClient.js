/**
 * Provides a base HTTP client for the Ansible AWX REST API with generic
 * resource operations. Always Bearer-mode; the token is obtained separately
 * from AnsibleAWXAuthClient.
 * @returns {Any} The AnsibleAWXBackendClient class.
 */
(function () {
    /**
     * Base HTTP client that adds the Bearer token to every AWX API request
     * and provides shared resource-lookup and HTTP-verb helpers used by the
     * typed sub-clients (Job, Project, Inventory, Credential, Organization).
     * @class
     * @param {REST:RESTHost} restHost - The AWX HTTP REST host.
     * @param {string} token - The Bearer token from AnsibleAWXAuthClient.
     * @returns {Any} An instance of the AnsibleAWXBackendClient class.
     */
    function AnsibleAWXBackendClient(restHost, token) {
        if (!restHost || System.getObjectType(restHost) !== "REST:RESTHost") {
            throw new ReferenceError(
                "restHost is required and must be of type 'REST:RESTHost'"
            );
        }

        if (!token || typeof token !== "string") {
            throw new ReferenceError(
                "token is required and must be of type 'string'"
            );
        }

        this.mediaType = "application/json";
        this.baseUri = "/api/v2";
        this.sessionHeaders = new Properties();
        this.restHost = restHost;
        this.sessionHeaders.put("Authorization", "Bearer " + token);

        HttpRestClient.call(this, this.restHost);

        this.log = new (System.getModule(
            "com.simplygeek.vcf.orchestrator.logging"
        ).Logger())("Action", "AnsibleAWXBackendClient");
    }

    var HttpRestClient = System.getModule(
        "com.simplygeek.rest"
    ).HttpRestClient();

    AnsibleAWXBackendClient.prototype = Object.create(HttpRestClient.prototype);
    AnsibleAWXBackendClient.prototype.constructor = AnsibleAWXBackendClient;

    // #############################
    // ## Generic Resource Methods #
    // #############################

    /**
     * Fetches a single AWX resource by its numeric ID, given the AWX
     * collection name (e.g. "organizations", "projects"). Returns the parsed
     * resource object; if the ID is not found, throws unless
     * throwOnNotFound is explicitly set to false.
     * @function
     * @public
     * @param {number} resourceId - The resource ID.
     * @param {string} resourceType - The AWX collection name (e.g.
     *     "organizations").
     * @param {boolean} [throwOnNotFound] - Whether to throw when the resource
     *     is not found. Defaults to true.
     * @returns {Any} The resource object.
     */

    AnsibleAWXBackendClient.prototype.getResourceById = function (
        resourceId,
        resourceType,
        throwOnNotFound
    ) {
        if (
            (!resourceId && resourceId !== 0) ||
            typeof resourceId !== "number"
        ) {
            throw new ReferenceError(
                "resourceId is required and must be of type 'number'"
            );
        }

        if (!resourceType || typeof resourceType !== "string") {
            throw new ReferenceError(
                "resourceType is required and must be of type 'string'"
            );
        }

        if (
            throwOnNotFound !== undefined &&
            throwOnNotFound !== null &&
            typeof throwOnNotFound !== "boolean"
        ) {
            throw new TypeError("throwOnNotFound must be of type 'boolean'");
        }

        // Default throwOnNotFound to true, unless explicitly set to false.
        throwOnNotFound = throwOnNotFound !== false;

        var uri =
            this.baseUri +
            "/" +
            resourceType.toLowerCase() +
            "/" +
            resourceId.toString() +
            "/";
        var resourceObject;

        this.log.info(
            "Get resource '" + resourceType + "' with id '" + resourceId + "'"
        );
        resourceObject = this.get(uri, [200, 404]);

        if (resourceObject.id) {
            var resourceName = resourceObject.name;

            this.log.info(
                "Found resource '" +
                    resourceType +
                    "' with name '" +
                    resourceName +
                    "' and id '" +
                    resourceId +
                    "'"
            );
        } else {
            var errMsg =
                "No resource found for '" +
                resourceType +
                "' with id '" +
                resourceId +
                "'";

            if (throwOnNotFound) {
                throw new Error(errMsg);
            } else {
                this.log.warn(errMsg);
            }
        }

        return resourceObject;
    };

    /**
     * Searches an AWX collection by name (server-side ?search=) and returns
     * the single matching resource. Throws if more than one resource matches,
     * and throws on no match unless throwOnNotFound is explicitly false.
     * @function
     * @public
     * @param {string} resourceName - The resource name to search for.
     * @param {string} resourceType - The AWX collection name (e.g. "teams").
     * @param {boolean} [throwOnNotFound] - Whether to throw when no resource
     *     matches. Defaults to true.
     * @returns {Any} The resource object.
     */

    AnsibleAWXBackendClient.prototype.getResourceByName = function (
        resourceName,
        resourceType,
        throwOnNotFound
    ) {
        if (!resourceName || typeof resourceName !== "string") {
            throw new ReferenceError(
                "resourceName is required and must be of type 'string'"
            );
        }

        if (!resourceType || typeof resourceType !== "string") {
            throw new ReferenceError(
                "resourceType is required and must be of type 'string'"
            );
        }

        if (
            throwOnNotFound !== undefined &&
            throwOnNotFound !== null &&
            typeof throwOnNotFound !== "boolean"
        ) {
            throw new TypeError("throwOnNotFound must be of type 'boolean'");
        }

        // Default throwOnNotFound to true, unless explicitly set to false.
        throwOnNotFound = throwOnNotFound !== false;

        var uri =
            this.baseUri + "/" + resourceType + "/?search=" + resourceName;
        var resourceObject;

        this.log.info(
            "Get resource '" +
                resourceType +
                "' with name '" +
                resourceName +
                "'"
        );

        var results = this.get(uri, [200, 404]);

        if (results.length > 1) {
            throw new Error(
                "More than one resource found. Unable to determine correct " +
                    "resource '" +
                    resourceType +
                    "' with name '" +
                    resourceName +
                    "'"
            );
        } else if (results.length > 0) {
            resourceObject = results[0];

            var resourceId = resourceObject.id;

            this.log.info(
                "Found resource '" +
                    resourceType +
                    "' with name '" +
                    resourceName +
                    "' and id '" +
                    resourceId +
                    "'"
            );
        } else {
            var errMsg =
                "No resource found for '" +
                resourceType +
                "' with name '" +
                resourceName +
                "'";

            if (throwOnNotFound) {
                throw new Error(errMsg);
            } else {
                this.log.warn(errMsg);
            }
        }

        return resourceObject;
    };

    // ########################
    // ## Private HTTP Methods #
    // ########################

    /**
     * Performs a GET against the AWX API and parses the JSON response. When
     * the response is a paged collection (has a `count` field), follows
     * subsequent pages and concatenates their `results` arrays into a single
     * flat list.
     * @function
     * @private
     * @param {string} uri - The request URI.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [200].
     * @returns {Any||Array/Any} The parsed object for a single resource, or
     *     the concatenated results array for a paged collection.
     */

    AnsibleAWXBackendClient.prototype.get = function (
        uri,
        expectedResponseCodes
    ) {
        if (!uri || typeof uri !== "string") {
            throw new ReferenceError(
                "uri is required and must be of type 'string'"
            );
        }

        if (
            !expectedResponseCodes ||
            (Array.isArray(expectedResponseCodes) &&
                expectedResponseCodes.length < 1)
        ) {
            expectedResponseCodes = [200];
        }

        var result;
        var response = this.httpGet(
            uri,
            this.mediaType,
            expectedResponseCodes,
            this.sessionHeaders
        );
        var responseContent = JSON.parse(response.contentAsString);

        if (responseContent.count) {
            var numTotalResults = responseContent.count;
            var results = responseContent.results;
            var numResultsOnPage = results.length;

            this.log.debug(
                "Found " +
                    numResultsOnPage +
                    " of " +
                    numTotalResults +
                    " results"
            );

            if (numResultsOnPage > 0 && numResultsOnPage < numTotalResults) {
                var nextPage = 2;
                var pageSize = numResultsOnPage;
                var uriSep = uri.indexOf("?") > -1 ? "&" : "?";

                do {
                    this.log.debug("Getting additional results");

                    var uriWithParams =
                        uri +
                        uriSep +
                        "page_size=" +
                        pageSize +
                        "&page=" +
                        nextPage;

                    response = this.httpGet(
                        uriWithParams,
                        this.mediaType,
                        expectedResponseCodes,
                        this.sessionHeaders
                    );
                    responseContent = JSON.parse(response.contentAsString);
                    results = results.concat(responseContent.results);
                    this.log.debug(
                        "Found " +
                            results.length +
                            " of " +
                            numTotalResults +
                            " results"
                    );
                    nextPage++;
                } while (results.length < numTotalResults);
            }
        } else {
            result = responseContent;
        }

        return result || results;
    };

    /**
     * Performs a POST against the AWX API. Parses and returns the JSON
     * response body unless the server responds with 204 No Content, in which
     * case undefined is returned.
     * @function
     * @private
     * @param {string} uri - The request URI.
     * @param {Any} [content] - The JSON request body.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [201].
     * @returns {Any} The parsed response body, or undefined for 204.
     */

    AnsibleAWXBackendClient.prototype.post = function (
        uri,
        content,
        expectedResponseCodes
    ) {
        if (!uri || typeof uri !== "string") {
            throw new ReferenceError(
                "uri is required and must be of type 'string'"
            );
        }

        if (
            !expectedResponseCodes ||
            (Array.isArray(expectedResponseCodes) &&
                expectedResponseCodes.length < 1)
        ) {
            expectedResponseCodes = [201];
        }

        var response = this.httpPost(
            uri,
            this.mediaType,
            content,
            this.mediaType,
            expectedResponseCodes,
            this.sessionHeaders
        );
        var responseContent;

        if (response.statusCode !== 204) {
            responseContent = JSON.parse(response.contentAsString);
        }

        return responseContent;
    };

    /**
     * Performs a PUT against the AWX API for a full resource replacement and
     * returns the parsed JSON response body.
     * @function
     * @private
     * @param {string} uri - The request URI.
     * @param {Any} content - The JSON request body.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [200].
     * @returns {Any} The parsed response body.
     */

    AnsibleAWXBackendClient.prototype.put = function (
        uri,
        content,
        expectedResponseCodes
    ) {
        if (!uri || typeof uri !== "string") {
            throw new ReferenceError(
                "uri is required and must be of type 'string'"
            );
        }

        if (!content || typeof content !== "object") {
            throw new ReferenceError(
                "content is required and must be of type 'object'"
            );
        }

        if (
            !expectedResponseCodes ||
            (Array.isArray(expectedResponseCodes) &&
                expectedResponseCodes.length < 1)
        ) {
            expectedResponseCodes = [200];
        }

        var response = this.httpPut(
            uri,
            this.mediaType,
            content,
            this.mediaType,
            expectedResponseCodes,
            this.sessionHeaders
        );
        var responseContent = JSON.parse(response.contentAsString);

        return responseContent;
    };

    /**
     * Performs a PATCH against the AWX API for a partial resource update and
     * returns the parsed JSON response body.
     * @function
     * @private
     * @param {string} uri - The request URI.
     * @param {Any} content - The JSON request body containing the fields to
     *     update.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [200].
     * @returns {Any} The parsed response body.
     */

    AnsibleAWXBackendClient.prototype.patch = function (
        uri,
        content,
        expectedResponseCodes
    ) {
        if (!uri || typeof uri !== "string") {
            throw new ReferenceError(
                "uri is required and must be of type 'string'"
            );
        }

        if (!content || typeof content !== "object") {
            throw new ReferenceError(
                "content is required and must be of type 'object'"
            );
        }

        if (
            !expectedResponseCodes ||
            (Array.isArray(expectedResponseCodes) &&
                expectedResponseCodes.length < 1)
        ) {
            expectedResponseCodes = [200];
        }

        var response = this.httpPatch(
            uri,
            this.mediaType,
            content,
            this.mediaType,
            expectedResponseCodes,
            this.sessionHeaders
        );
        var responseContent = JSON.parse(response.contentAsString);

        return responseContent;
    };

    /**
     * Performs a DELETE against the AWX API for the given resource URI.
     * @function
     * @private
     * @param {string} uri - The request URI.
     * @param {Array/number} [expectedResponseCodes] - Acceptable HTTP status
     *     codes. Defaults to [204].
     */

    AnsibleAWXBackendClient.prototype.delete = function (
        uri,
        expectedResponseCodes
    ) {
        if (!uri || typeof uri !== "string") {
            throw new ReferenceError(
                "uri is required and must be of type 'string'"
            );
        }

        if (
            !expectedResponseCodes ||
            (Array.isArray(expectedResponseCodes) &&
                expectedResponseCodes.length < 1)
        ) {
            expectedResponseCodes = [204];
        }

        this.httpDelete(
            uri,
            this.mediaType,
            expectedResponseCodes,
            this.sessionHeaders
        );
    };

    return AnsibleAWXBackendClient;
});
