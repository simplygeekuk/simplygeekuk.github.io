/**
 * Provides an Ansible AWX Job Template specification object for use with
 * AnsibleAWXJobClient.createJobTemplate / .updateJobTemplate.
 * @returns {Any} The JobTemplate class.
 */
(function () {
    /**
     * Specification for an AWX Job Template (a runnable binding of a
     * playbook, project, and inventory). Job Templates are launched to
     * create individual jobs.
     * @class
     * @param {string} name - The job template name.
     * @param {number} inventoryId - The inventory ID jobs will run against.
     * @param {number} projectId - The project ID providing the playbook.
     * @param {string} playbook - The playbook filename within the project.
     * @param {string} [jobType] - 'run' (default) or 'check'.
     * @param {string} [limit] - Host or group limit pattern.
     * @param {string} [scmBranch] - Override the project's SCM branch.
     * @param {Any} [extraVars] - Extra variables (string or object).
     * @param {string} [description] - Optional description.
     * @returns {Any} An instance of the JobTemplate class.
     */
    function JobTemplate(
        name,
        inventoryId,
        projectId,
        playbook,
        jobType,
        limit,
        scmBranch,
        extraVars,
        description
    ) {
        var validJobTypes = ["run", "check"];

        if (!name || typeof name !== "string") {
            throw new ReferenceError(
                "name is required and must be of type 'string'"
            );
        }

        if (
            (!inventoryId && inventoryId !== 0) ||
            typeof inventoryId !== "number"
        ) {
            throw new ReferenceError(
                "inventoryId is required and must be of type 'number'"
            );
        }

        if ((!projectId && projectId !== 0) || typeof projectId !== "number") {
            throw new ReferenceError(
                "projectId is required and must be of type 'number'"
            );
        }

        if (!playbook || typeof playbook !== "string") {
            throw new ReferenceError(
                "playbook is required and must be of type 'string'"
            );
        }

        if (
            jobType !== undefined &&
            jobType !== null &&
            typeof jobType !== "string"
        ) {
            throw new TypeError("jobType must be of type 'string'");
        }

        if (jobType && validJobTypes.indexOf(jobType) < 0) {
            throw new RangeError(
                "Unsupported jobType '" +
                    jobType +
                    "'. Supported values: " +
                    validJobTypes.join(", ")
            );
        }

        if (
            limit !== undefined &&
            limit !== null &&
            typeof limit !== "string"
        ) {
            throw new TypeError("limit must be of type 'string'");
        }

        if (
            scmBranch !== undefined &&
            scmBranch !== null &&
            typeof scmBranch !== "string"
        ) {
            throw new TypeError("scmBranch must be of type 'string'");
        }

        if (
            extraVars !== undefined &&
            extraVars !== null &&
            typeof extraVars !== "string" &&
            typeof extraVars !== "object"
        ) {
            throw new TypeError(
                "extraVars must be of type 'string' or 'object'"
            );
        }

        if (
            description !== undefined &&
            description !== null &&
            typeof description !== "string"
        ) {
            throw new TypeError("description must be of type 'string'");
        }

        this.name = name;
        this.inventory = inventoryId;
        this.project = projectId;
        this.playbook = playbook;

        if (jobType) this.job_type = jobType;

        if (limit) this.limit = limit;

        if (scmBranch) this.scm_branch = scmBranch;

        if (extraVars) this.extra_vars = extraVars;

        if (description) this.description = description;
    }

    return JobTemplate;
});
