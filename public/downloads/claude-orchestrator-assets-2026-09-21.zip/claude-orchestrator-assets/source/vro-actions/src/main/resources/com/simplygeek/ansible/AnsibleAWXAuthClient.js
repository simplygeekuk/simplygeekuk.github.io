/**
 * Provides an Ansible AWX client for token-based authentication and OAuth2
 * application management. This is the only client that requires credentials.
 * Call authenticate() to obtain a Bearer token, then pass that token to all
 * other AWX clients. Call closeSession() when finished to revoke the token.
 * @returns {Any} The AnsibleAWXAuthClient class.
 */
(function () {
    /**
     * Client that exchanges Basic-auth credentials for a short-lived OAuth2
     * Bearer token via the AWX /tokens/ endpoint, manages the token's
     * lifecycle (authenticate / closeSession / withSession), and exposes CRUD
     * methods for AWX OAuth2 Applications. The only AWX client that requires
     * raw credentials.
     * @class
     * @param {REST:RESTHost} restHost - The AWX HTTP REST host.
     * @param {string} username - The basic auth username.
     * @param {string} password - The basic auth password.
     * @returns {Any} An instance of the AnsibleAWXAuthClient class.
     */
    function AnsibleAWXAuthClient(restHost, username, password) {
        if (!restHost || System.getObjectType(restHost) !== "REST:RESTHost") {
            throw new ReferenceError(
                "restHost is required and must be of type 'REST:RESTHost'"
            );
        }

        if (!username || typeof username !== "string") {
            throw new ReferenceError(
                "username is required and must be of type 'string'"
            );
        }

        if (!password || typeof password !== "string") {
            throw new ReferenceError(
                "password is required and must be of type 'string'"
            );
        }

        this.restHost = restHost;
        this.username = username;
        this.password = password;
        this.mediaType = "application/json";
        this.baseUri = "/api/v2";
        this.sessionHeaders = new Properties();
        this.session = null;

        this.log = new (System.getModule(
            "com.simplygeek.vcf.orchestrator.logging"
        ).Logger())("Action", "AnsibleAWXAuthClient");
    }

    var AnsibleAWXBackendClient = System.getModule(
        "com.simplygeek.ansible"
    ).AnsibleAWXBackendClient();
    var HttpRestClient = System.getModule(
        "com.simplygeek.rest"
    ).HttpRestClient();

    AnsibleAWXAuthClient.prototype = Object.create(
        AnsibleAWXBackendClient.prototype
    );
    AnsibleAWXAuthClient.prototype.constructor = AnsibleAWXAuthClient;

    // ####################
    // ## Authentication ##
    // ####################

    /**
     * Exchanges the stored Basic-auth credentials for an OAuth2 Bearer token.
     * The Basic-auth bootstrap is performed against a transient clone of the
     * REST host so the caller's host is never mutated. After success, the
     * instance switches to Bearer mode for any subsequent application-
     * management calls and the new token is returned.
     * @function
     * @public
     * @param {number} applicationId - The AWX application ID.
     * @param {string} scope - The authorization scope ('read' or 'write').
     * @returns {string} The Bearer token for use with all other AWX clients.
     */

    AnsibleAWXAuthClient.prototype.authenticate = function (
        applicationId,
        scope
    ) {
        if (
            (!applicationId && applicationId !== 0) ||
            typeof applicationId !== "number"
        ) {
            throw new ReferenceError(
                "applicationId is required and must be of type 'number'"
            );
        }

        var validScopes = ["read", "write"];

        if (!scope || typeof scope !== "string") {
            throw new ReferenceError(
                "scope is required and must be of type 'string'"
            );
        } else if (validScopes.indexOf(scope) < 0) {
            throw new RangeError(
                "Invalid scope '" +
                    scope +
                    "'." +
                    " Supported scopes: " +
                    validScopes.join(", ")
            );
        }

        var basicAuth = RESTAuthenticationManager.createAuthentication(
            "Basic",
            ["Shared Session", this.username, this.password]
        );
        var transientHost = RESTHostManager.createTransientHostFrom(
            this.restHost
        );

        transientHost.authentication = basicAuth;

        var bootstrapClient = new HttpRestClient(transientHost);
        var uri = this.baseUri + "/tokens/";
        var content = {
            application: applicationId,
            scope: scope,
        };

        this.log.debug("Requesting authentication token");

        var response = bootstrapClient.httpPost(
            uri,
            this.mediaType,
            content,
            this.mediaType,
            [201]
        );

        this.session = JSON.parse(response.contentAsString);

        // Initialise self as a Bearer-mode backend client on the original
        // (untouched) host so application-management calls run with only
        // the Bearer header.
        AnsibleAWXBackendClient.call(this, this.restHost, this.session.token);
        this.log.debug("Authentication token obtained");

        return this.session.token;
    };

    /**
     * Revokes the currently held Bearer token via DELETE /tokens/{id}/, then
     * clears the in-memory session and the Authorization header so the
     * client is in a clean post-close state. Idempotent and safe to call
     * before authenticate() or twice in succession (e.g. from a finally
     * block).
     * @function
     * @public
     */

    AnsibleAWXAuthClient.prototype.closeSession = function () {
        if (!this.session) {
            return;
        }

        var uri = this.baseUri + "/tokens/" + this.session.id + "/";

        this.log.debug("Revoking authentication token");

        try {
            this.httpDelete(uri, this.mediaType, [204], this.sessionHeaders);
            this.log.debug("Authentication token revoked");
        } catch (e) {
            this.log.warn(
                "Failed to revoke token, perhaps it has already expired. " + e
            );
        }

        this.session = null;
        this.sessionHeaders.remove("Authorization");
    };

    /**
     * Convenience wrapper that calls authenticate(), invokes the supplied
     * callback with the resulting Bearer token, and guarantees
     * closeSession() runs in a finally block — even if the callback throws.
     * The callback's return value is propagated as withSession's result.
     * @function
     * @public
     * @param {number} applicationId - The AWX application ID.
     * @param {string} scope - The authorization scope ('read' or 'write').
     * @param {function(string): Any} callback - Invoked with the Bearer
     *     token; its return value is returned from withSession.
     * @returns {Any} The value returned by the callback.
     */

    AnsibleAWXAuthClient.prototype.withSession = function (
        applicationId,
        scope,
        callback
    ) {
        if (typeof callback !== "function") {
            throw new TypeError("callback must be of type 'function'");
        }

        this.authenticate(applicationId, scope);

        try {
            return callback(this.session.token);
        } finally {
            this.closeSession();
        }
    };

    // ##################
    // ## Applications ##
    // ##################

    /**
     * Fetches a single AWX OAuth2 Application by its numeric ID.
     * @function
     * @public
     * @param {number} applicationId - The application ID.
     * @param {boolean} [throwOnNotFound] - Whether to throw when the
     *     application is not found. Defaults to true.
     * @returns {Any} The application object.
     */

    AnsibleAWXAuthClient.prototype.getApplicationById = function (
        applicationId,
        throwOnNotFound
    ) {
        if (
            (!applicationId && applicationId !== 0) ||
            typeof applicationId !== "number"
        ) {
            throw new ReferenceError(
                "applicationId is required and must be of type 'number'"
            );
        }

        var resourceType = "applications";
        var applicationObject = this.getResourceById(
            applicationId,
            resourceType,
            throwOnNotFound
        );

        return applicationObject;
    };

    /**
     * Searches AWX OAuth2 Applications by name and returns the single match.
     * @function
     * @public
     * @param {string} applicationName - The application name.
     * @param {boolean} [throwOnNotFound] - Whether to throw when no
     *     application matches. Defaults to true.
     * @returns {Any} The application object.
     */

    AnsibleAWXAuthClient.prototype.getApplicationByName = function (
        applicationName,
        throwOnNotFound
    ) {
        if (!applicationName || typeof applicationName !== "string") {
            throw new ReferenceError(
                "applicationName is required and must be of type 'string'"
            );
        }

        var resourceType = "applications";
        var applicationObject = this.getResourceByName(
            applicationName,
            resourceType,
            throwOnNotFound
        );

        return applicationObject;
    };

    /**
     * Creates a new AWX OAuth2 Application from the supplied specification.
     * The returned object includes the generated client_id and client_secret.
     * @function
     * @public
     * @param {Any} applicationSpecification - The application specification.
     * @returns {Any} The new application object.
     */

    AnsibleAWXAuthClient.prototype.createApplication = function (
        applicationSpecification
    ) {
        if (
            !applicationSpecification ||
            typeof applicationSpecification !== "object"
        ) {
            throw new ReferenceError(
                "applicationSpecification is required and must " +
                    "be of type 'object'"
            );
        }

        var uri = this.baseUri + "/applications/";
        var applicationObject;

        this.log.debug(
            "Creating application '" + applicationSpecification.name + "'"
        );
        applicationObject = this.post(uri, applicationSpecification);
        this.log.debug("Application successfully created");

        return applicationObject;
    };

    /**
     * Patches an existing AWX OAuth2 Application with the supplied fields
     * (partial update via PATCH). Use to rotate name, description, or scope.
     * @function
     * @public
     * @param {number} applicationId - The application ID.
     * @param {Any} applicationSpecification - The fields to update.
     * @returns {Any} The updated application object.
     */

    AnsibleAWXAuthClient.prototype.updateApplication = function (
        applicationId,
        applicationSpecification
    ) {
        if (
            (!applicationId && applicationId !== 0) ||
            typeof applicationId !== "number"
        ) {
            throw new ReferenceError(
                "applicationId is required and must be of type 'number'"
            );
        }

        if (
            !applicationSpecification ||
            typeof applicationSpecification !== "object"
        ) {
            throw new ReferenceError(
                "applicationSpecification is required and must " +
                    "be of type 'object'"
            );
        }

        var uri =
            this.baseUri + "/applications/" + applicationId.toString() + "/";
        var applicationObject;

        this.log.debug("Updating application with id '" + applicationId + "'");
        applicationObject = this.patch(uri, applicationSpecification);
        this.log.debug("Application successfully updated");

        return applicationObject;
    };

    /**
     * Deletes an AWX OAuth2 Application by ID. All Bearer tokens issued
     * against the application become invalid.
     * @function
     * @public
     * @param {number} applicationId - The application ID.
     */

    AnsibleAWXAuthClient.prototype.deleteApplication = function (
        applicationId
    ) {
        if (
            (!applicationId && applicationId !== 0) ||
            typeof applicationId !== "number"
        ) {
            throw new ReferenceError(
                "applicationId is required and must be of type 'number'"
            );
        }

        var uri =
            this.baseUri + "/applications/" + applicationId.toString() + "/";

        this.log.debug("Deleting application with id '" + applicationId + "'");
        this.delete(uri);
        this.log.debug("Application successfully deleted");
    };

    return AnsibleAWXAuthClient;
});
