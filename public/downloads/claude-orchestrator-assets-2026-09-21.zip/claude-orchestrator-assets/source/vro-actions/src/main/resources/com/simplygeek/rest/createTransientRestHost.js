/**
 * This function creates a transient/dynamic rest host.
 * @param {string} restHostUrl - The Web Service URL.
 * @param {string} [restHostName] - The name of the rest host.
 * @param {number} [connectionTimeout] - The connection timeout in seconds. Default 120; 0 also takes the default.
 * @param {number} [operationTimeout] - The operation timeout in seconds. Default 240; 0 also takes the default.
 * @param {boolean} [hostVerification] - Should verify hostname certificate.
 * @param {string} [authenticationType] - The authentication type (default NONE)
 * @param {string} [basicUsername] - The username if Basic authentication is used.
 * @param {SecureString} [basicPassword] - The password if Basic authentication is used.
 * @param {string} [apiToken] - The API Bearer Token if Oauth2 authentication is used.
 * @param {string} [proxyHost] - Hostname or IP of an HTTP proxy.
 * @param {number} [proxyPort] - Port of the HTTP proxy. Required when proxyHost is set.
 * @returns {REST:RESTHost} - The RESTHost vRO type
 */
(function (
    restHostUrl,
    restHostName,
    connectionTimeout,
    operationTimeout,
    hostVerification,
    authenticationType,
    basicUsername,
    basicPassword,
    apiToken,
    proxyHost,
    proxyPort
) {
    var log = new (System.getModule(
        "com.simplygeek.vcf.orchestrator.logging"
    ).Logger())("Action", "createTransientRestHost");
    var urlRegex =
        /^https?:\/\/[-a-zA-Z0-9@:%._+~#=]{1,256}(?::[0-9]{1,5})?\/?(?:[-a-zA-Z0-9()@:%_+.~#?&/=]*)?$/i;
    var validAuthTypes = ["basic", "oauth2"];

    // Mandatory param check
    if (!restHostUrl || typeof restHostUrl !== "string") {
        throw new ReferenceError(
            "restHostUrl is required and must be of type 'string'"
        );
    } else if (restHostUrl && !restHostUrl.match(urlRegex)) {
        throw new RangeError("restHostUrl not a valid URI");
    }

    // Optional param check
    if (
        restHostName !== undefined &&
        restHostName !== null &&
        typeof restHostName !== "string"
    ) {
        throw new TypeError("restHostName must be of type 'string'");
    }

    if (
        connectionTimeout !== undefined &&
        connectionTimeout !== null &&
        typeof connectionTimeout !== "number"
    ) {
        throw new TypeError("connectionTimeout must be of type 'number'");
    }

    if (
        operationTimeout !== undefined &&
        operationTimeout !== null &&
        typeof operationTimeout !== "number"
    ) {
        throw new TypeError("operationTimeout must be of type 'number'");
    }

    if (
        hostVerification !== undefined &&
        hostVerification !== null &&
        typeof hostVerification !== "boolean"
    ) {
        throw new TypeError("hostVerification must be of type 'boolean'");
    }

    if (
        authenticationType !== undefined &&
        authenticationType !== null &&
        typeof authenticationType !== "string"
    ) {
        throw new TypeError("authenticationType must be of type 'string'");
    } else if (
        authenticationType &&
        validAuthTypes.indexOf(authenticationType.toLowerCase()) < 0
    ) {
        throw new RangeError(
            "Invalid authentication type '" +
                authenticationType +
                "'." +
                " Supported authentication types: " +
                validAuthTypes.join(", ")
        );
    } else if (
        authenticationType &&
        authenticationType.toLowerCase() === "basic" &&
        (!basicUsername || !basicPassword)
    ) {
        throw new Error(
            "A Username and Password must be provided to use Basic authentication"
        );
    } else if (
        authenticationType &&
        authenticationType.toLowerCase() === "oauth2" &&
        !apiToken
    ) {
        throw new Error(
            "An API Token must be provided to use OAuth2 authentication"
        );
    }

    if (
        proxyHost !== undefined &&
        proxyHost !== null &&
        typeof proxyHost !== "string"
    ) {
        throw new TypeError("proxyHost must be of type 'string'");
    }

    if (
        proxyPort !== undefined &&
        proxyPort !== null &&
        typeof proxyPort !== "number"
    ) {
        throw new TypeError("proxyPort must be of type 'number'");
    } else if (proxyPort && !proxyHost) {
        throw new Error("proxyHost is required when proxyPort is set");
    }

    var name = restHostName || "dynamicHost";
    var authParams;

    log.debug(
        "Creating transient rest host '" +
            name +
            "' with url '" +
            restHostUrl +
            "'"
    );
    var restHost = RESTHostManager.createTransientHostFrom(
        RESTHostManager.createHost(name)
    );

    restHost.url = restHostUrl;
    restHost.connectionTimeout = connectionTimeout || 120;
    restHost.operationTimeout = operationTimeout || 240;
    restHost.hostVerification = hostVerification !== false;

    if (proxyHost) {
        log.debug(
            "Setting proxy '" +
                proxyHost +
                (proxyPort ? ":" + proxyPort : "") +
                "'"
        );
        restHost.proxyHost = proxyHost;

        if (proxyPort) {
            restHost.proxyPort = proxyPort;
        }
    }

    if (authenticationType && authenticationType.toLowerCase() === "basic") {
        log.debug("Setting Basic Authentication");
        authParams = ["Shared Session", basicUsername, basicPassword];
        restHost.authentication =
            RESTAuthenticationManager.createAuthentication("Basic", authParams);
    } else if (
        authenticationType &&
        authenticationType.toLowerCase() === "oauth2"
    ) {
        log.debug("Setting OAuth2 Authentication");
        authParams = [apiToken, "Authorization header"];
        restHost.authentication =
            RESTAuthenticationManager.createAuthentication(
                "OAuth 2.0",
                authParams
            );
    }

    return restHost;
});
