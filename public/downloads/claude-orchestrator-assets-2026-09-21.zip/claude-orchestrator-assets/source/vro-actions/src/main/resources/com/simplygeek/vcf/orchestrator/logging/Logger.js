/**
 * Logger class used for sending standard log messages to the console.
 * @returns {Any} - returns an instance of the Logger class
 */
(function () {
    /**
     * Logger class used for sending standard log messages to the console.
     * @class
     * @param {string} logSource - The log source. Valid sources are Action or Workflow.
     * @param {string} logName - The name of the Action or Workflow sending the log message.
     */
    function Logger(logSource, logName) {
        var validSources = ["action", "workflow"];

        if (
            logSource !== undefined &&
            logSource !== null &&
            typeof logSource !== "string"
        ) {
            throw new TypeError("logSource must be of type 'string'");
        } else if (
            logSource &&
            validSources.indexOf(logSource.toLowerCase()) < 0
        ) {
            throw new RangeError(
                "Unsupported source '" +
                    logSource +
                    "'." +
                    " Supported sources: " +
                    validSources.join(", ")
            );
        }

        this.type = logSource;
        this.name = logName;
    }

    /**
     * Builds the prefixed log line. When no message is supplied, returns the
     * bare prefix without a trailing space — useful for marking start/end
     * boundaries in long logs.
     * @function
     * @private
     * @param {string} [message] - The optional message body.
     * @returns {string} The fully formatted log line.
     */

    Logger.prototype.formatMessage = function (message) {
        var prefix = "[" + this.type + ": " + this.name + "]";

        return message ? prefix + " " + message : prefix;
    };

    /**
     * Prints INFO messages to the console.
     * @function
     * @public
     * @param {string} [message] - The optional message body.
     */

    Logger.prototype.info = function (message) {
        System.log(this.formatMessage(message));
    };

    /**
     * Prints WARNING messages to the console.
     * @function
     * @public
     * @param {string} [message] - The optional message body.
     */

    Logger.prototype.warn = function (message) {
        System.warn(this.formatMessage(message));
    };

    /**
     * Prints ERROR messages to the console.
     * @function
     * @public
     * @param {string} [message] - The optional message body.
     */

    Logger.prototype.error = function (message) {
        System.error(this.formatMessage(message));
    };

    /**
     * Prints DEBUG messages to the console.
     * @function
     * @public
     * @param {string} [message] - The optional message body.
     */

    Logger.prototype.debug = function (message) {
        System.debug(this.formatMessage(message));
    };

    return Logger;
});
