/**
 * Provides an Ansible AWX client for managing job templates and jobs.
 * @returns {Any} The AnsibleAWXJobClient class.
 */
(function () {
    /**
     * Client for AWX job templates and jobs. Covers job-template CRUD,
     * launching templates (with optional extra vars / limit), querying job
     * status, retrieving stdout, listing jobs by template, and cancelling
     * running jobs.
     * @class
     * @param {REST:RESTHost} restHost - The AWX HTTP REST host.
     * @param {string} token - The Bearer token from AnsibleAWXAuthClient.
     * @returns {Any} An instance of the AnsibleAWXJobClient class.
     */
    function AnsibleAWXJobClient(restHost, token) {
        AnsibleAWXBackendClient.call(this, restHost, token);

        this.log = new (System.getModule(
            "com.simplygeek.vcf.orchestrator.logging"
        ).Logger())("Action", "AnsibleAWXJobClient");
    }

    var AnsibleAWXBackendClient = System.getModule(
        "com.simplygeek.ansible"
    ).AnsibleAWXBackendClient();

    AnsibleAWXJobClient.prototype = Object.create(
        AnsibleAWXBackendClient.prototype
    );
    AnsibleAWXJobClient.prototype.constructor = AnsibleAWXJobClient;

    // ###################
    // ## Job Templates ##
    // ###################

    /**
     * Retrieves all AWX job templates sorted by name. Pagination is handled
     * internally.
     * @function
     * @public
     * @returns {Array/Any} The list of job templates.
     */

    AnsibleAWXJobClient.prototype.getJobTemplates = function () {
        var uri = this.baseUri + "/job_templates/?order_by=name";
        var results;

        this.log.debug("Getting list of job templates");
        results = this.get(uri);
        this.log.debug("Found " + results.length + " job templates");

        return results;
    };

    /**
     * Fetches a single AWX job template by its numeric ID.
     * @function
     * @public
     * @param {number} jobTemplateId - The job template ID.
     * @param {boolean} [throwOnNotFound] - Whether to throw when the job
     *     template is not found. Defaults to true.
     * @returns {Any} The job template object.
     */

    AnsibleAWXJobClient.prototype.getJobTemplateById = function (
        jobTemplateId,
        throwOnNotFound
    ) {
        if (
            (!jobTemplateId && jobTemplateId !== 0) ||
            typeof jobTemplateId !== "number"
        ) {
            throw new ReferenceError(
                "jobTemplateId is required and must be of type 'number'"
            );
        }

        var resourceType = "job_templates";
        var jobTemplateObject = this.getResourceById(
            jobTemplateId,
            resourceType,
            throwOnNotFound
        );

        return jobTemplateObject;
    };

    /**
     * Searches AWX job templates by name and returns the single match.
     * @function
     * @public
     * @param {string} jobTemplateName - The job template name.
     * @param {boolean} [throwOnNotFound] - Whether to throw when no job
     *     template matches. Defaults to true.
     * @returns {Any} The job template object.
     */

    AnsibleAWXJobClient.prototype.getJobTemplateByName = function (
        jobTemplateName,
        throwOnNotFound
    ) {
        if (!jobTemplateName || typeof jobTemplateName !== "string") {
            throw new ReferenceError(
                "jobTemplateName is required and must be of type 'string'"
            );
        }

        var resourceType = "job_templates";
        var jobTemplateObject = this.getResourceByName(
            jobTemplateName,
            resourceType,
            throwOnNotFound
        );

        return jobTemplateObject;
    };

    /**
     * Triggers a run of the given job template via POST /launch/. The
     * optional launch spec may carry extra_vars, limit, inventory overrides,
     * etc. Returns immediately with the queued job object — does not wait
     * for completion.
     * @function
     * @public
     * @param {number} jobTemplateId - The job template ID.
     * @param {Any} [launchSpec] - The launch specification (extra vars,
     *     limit, etc.).
     * @returns {Any} The launched job object (use getJobStatus to poll).
     */

    AnsibleAWXJobClient.prototype.launchJobTemplate = function (
        jobTemplateId,
        launchSpec
    ) {
        if (
            (!jobTemplateId && jobTemplateId !== 0) ||
            typeof jobTemplateId !== "number"
        ) {
            throw new ReferenceError(
                "jobTemplateId is required and must be of type 'number'"
            );
        }

        var uri =
            this.baseUri +
            "/job_templates/" +
            jobTemplateId.toString() +
            "/launch/";
        var content = launchSpec || {};
        var jobObject;

        this.log.debug(
            "Launching job template with id '" + jobTemplateId + "'"
        );
        jobObject = this.post(uri, content, [201]);
        this.log.debug("Job launched with id '" + jobObject.id + "'");

        return jobObject;
    };

    /**
     * Creates a new AWX job template from the supplied specification.
     * @function
     * @public
     * @param {Any} jobTemplateSpecification - The job template specification.
     * @returns {Any} The new job template object.
     */

    AnsibleAWXJobClient.prototype.createJobTemplate = function (
        jobTemplateSpecification
    ) {
        if (
            !jobTemplateSpecification ||
            typeof jobTemplateSpecification !== "object"
        ) {
            throw new ReferenceError(
                "jobTemplateSpecification is required and must " +
                    "be of type 'object'"
            );
        }

        var uri = this.baseUri + "/job_templates/";
        var jobTemplateObject;

        this.log.debug(
            "Creating job template '" + jobTemplateSpecification.name + "'"
        );
        jobTemplateObject = this.post(uri, jobTemplateSpecification);
        this.log.debug("Job template successfully created");

        return jobTemplateObject;
    };

    /**
     * Patches an existing AWX job template with the supplied fields
     * (partial update via PATCH).
     * @function
     * @public
     * @param {number} jobTemplateId - The job template ID.
     * @param {Any} jobTemplateSpecification - The fields to update.
     * @returns {Any} The updated job template object.
     */

    AnsibleAWXJobClient.prototype.updateJobTemplate = function (
        jobTemplateId,
        jobTemplateSpecification
    ) {
        if (
            (!jobTemplateId && jobTemplateId !== 0) ||
            typeof jobTemplateId !== "number"
        ) {
            throw new ReferenceError(
                "jobTemplateId is required and must be of type 'number'"
            );
        }

        if (
            !jobTemplateSpecification ||
            typeof jobTemplateSpecification !== "object"
        ) {
            throw new ReferenceError(
                "jobTemplateSpecification is required and must " +
                    "be of type 'object'"
            );
        }

        var uri =
            this.baseUri + "/job_templates/" + jobTemplateId.toString() + "/";
        var jobTemplateObject;

        this.log.debug("Updating job template with id '" + jobTemplateId + "'");
        jobTemplateObject = this.patch(uri, jobTemplateSpecification);
        this.log.debug("Job template successfully updated");

        return jobTemplateObject;
    };

    /**
     * Deletes an AWX job template by ID. In-flight jobs spawned from the
     * template are not affected.
     * @function
     * @public
     * @param {number} jobTemplateId - The job template ID.
     */

    AnsibleAWXJobClient.prototype.deleteJobTemplate = function (jobTemplateId) {
        if (
            (!jobTemplateId && jobTemplateId !== 0) ||
            typeof jobTemplateId !== "number"
        ) {
            throw new ReferenceError(
                "jobTemplateId is required and must be of type 'number'"
            );
        }

        var uri =
            this.baseUri + "/job_templates/" + jobTemplateId.toString() + "/";

        this.log.debug("Deleting job template with id '" + jobTemplateId + "'");
        this.delete(uri);
        this.log.debug("Job template successfully deleted");
    };

    // ##########
    // ## Jobs ##
    // ##########

    /**
     * Fetches a single AWX job (a single execution of a template) by its
     * numeric ID.
     * @function
     * @public
     * @param {number} jobId - The job ID.
     * @param {boolean} [throwOnNotFound] - Whether to throw when the job is
     *     not found. Defaults to true.
     * @returns {Any} The job object.
     */

    AnsibleAWXJobClient.prototype.getJobById = function (
        jobId,
        throwOnNotFound
    ) {
        if ((!jobId && jobId !== 0) || typeof jobId !== "number") {
            throw new ReferenceError(
                "jobId is required and must be of type 'number'"
            );
        }

        var resourceType = "jobs";
        var jobObject = this.getResourceById(
            jobId,
            resourceType,
            throwOnNotFound
        );

        return jobObject;
    };

    /**
     * Returns just the status string for a job (e.g. "pending", "running",
     * "successful", "failed", "canceled"). Useful for polling loops where
     * the rest of the job object is not needed.
     * @function
     * @public
     * @param {number} jobId - The job ID.
     * @returns {string} The job status.
     */

    AnsibleAWXJobClient.prototype.getJobStatus = function (jobId) {
        if ((!jobId && jobId !== 0) || typeof jobId !== "number") {
            throw new ReferenceError(
                "jobId is required and must be of type 'number'"
            );
        }

        var jobObject = this.getJobById(jobId);

        this.log.debug(
            "Job '" + jobId + "' status is '" + jobObject.status + "'"
        );

        return jobObject.status;
    };

    /**
     * Cancels a running or pending job via POST /cancel/. The job
     * transitions to "canceled" asynchronously; this call does not wait for
     * the transition to complete.
     * @function
     * @public
     * @param {number} jobId - The job ID.
     */

    AnsibleAWXJobClient.prototype.cancelJob = function (jobId) {
        if ((!jobId && jobId !== 0) || typeof jobId !== "number") {
            throw new ReferenceError(
                "jobId is required and must be of type 'number'"
            );
        }

        var uri = this.baseUri + "/jobs/" + jobId.toString() + "/cancel/";

        this.log.debug("Cancelling job with id '" + jobId + "'");
        this.post(uri, {}, [202]);
        this.log.debug("Job successfully cancelled");
    };

    /**
     * Lists all jobs spawned from the given job template, sorted newest
     * first. Pagination is handled internally.
     * @function
     * @public
     * @param {number} jobTemplateId - The job template ID.
     * @returns {Array/Any} The list of jobs for the given template.
     */

    AnsibleAWXJobClient.prototype.getJobsByTemplate = function (jobTemplateId) {
        if (
            (!jobTemplateId && jobTemplateId !== 0) ||
            typeof jobTemplateId !== "number"
        ) {
            throw new ReferenceError(
                "jobTemplateId is required and must be of type 'number'"
            );
        }

        var uri =
            this.baseUri +
            "/job_templates/" +
            jobTemplateId.toString() +
            "/jobs/?order_by=-id";
        var results;

        this.log.debug(
            "Getting jobs for job template id '" + jobTemplateId + "'"
        );
        results = this.get(uri);
        this.log.debug("Found " + results.length + " jobs");

        return results;
    };

    /**
     * Retrieves the plain-text stdout for a job. Returns the raw playbook
     * output as a single string.
     * @function
     * @public
     * @param {number} jobId - The job ID.
     * @returns {string} The job stdout output.
     */

    AnsibleAWXJobClient.prototype.getJobOutput = function (jobId) {
        if ((!jobId && jobId !== 0) || typeof jobId !== "number") {
            throw new ReferenceError(
                "jobId is required and must be of type 'number'"
            );
        }

        var uri =
            this.baseUri + "/jobs/" + jobId.toString() + "/stdout/?format=txt";
        var response;

        this.log.debug("Getting output for job id '" + jobId + "'");
        response = this.httpGet(uri, "text/plain", [200], this.sessionHeaders);

        return response.contentAsString;
    };

    return AnsibleAWXJobClient;
});
