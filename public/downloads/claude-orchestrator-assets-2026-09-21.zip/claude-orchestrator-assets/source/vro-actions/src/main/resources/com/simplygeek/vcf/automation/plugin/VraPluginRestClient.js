/**
 * Provides a generic REST client for the VCF Automation APIs, using the
 * REST client provided by the Aria Automation plugin.
 * @returns {Any} - An instance of the VraPluginRestClient class.
 */
(function () {
    /**
     * Provides a generic REST client for the VCF Automation APIs, using
     * the REST client provided by the Aria Automation plugin.
     * @class
     * @param {VRA:Host} vraHost - The Aria Automation plugin host.
     * @returns {Any} An instance of the VraPluginRestClient class.
     */
    function VraPluginRestClient(vraHost) {
        if (!vraHost || typeof vraHost.createRestClient !== "function") {
            throw new ReferenceError(
                "vraHost is required and must be of type 'VRA:Host'"
            );
        }

        this.vraHost = vraHost;
        this.restClient = vraHost.createRestClient();
        this.log = new (System.getModule(
            "com.simplygeek.vcf.orchestrator.logging"
        ).Logger())("Action", "VraPluginRestClient");
        this.mediaType = "application/json";
    }

    /**
     * Executes a request with the plugin REST client and returns the
     * parsed JSON response content. Returns null when a 404 response
     * was listed as an expected status code.
     * @function
     * @public
     * @param {string} method - The HTTP method.
     * @param {string} uri - The request URI, relative to the host.
     * @param {object} [payload] - The (optional) request payload.
     * @param {Array/number} [expectedStatusCodes] - Expected status codes.
     * @returns {Any} The parsed response content.
     */

    VraPluginRestClient.prototype.executeRequest = function (
        method,
        uri,
        payload,
        expectedStatusCodes
    ) {
        if (!method || typeof method !== "string") {
            throw new ReferenceError(
                "method is required and must " + "be of type 'string'"
            );
        }

        if (!uri || typeof uri !== "string") {
            throw new ReferenceError(
                "uri is required and must " + "be of type 'string'"
            );
        }

        if (
            expectedStatusCodes !== undefined &&
            expectedStatusCodes !== null &&
            !Array.isArray(expectedStatusCodes)
        ) {
            throw new TypeError(
                "expectedStatusCodes must be of type 'Array/number'"
            );
        }

        var content = null;

        if (payload !== undefined && payload !== null) {
            content = JSON.stringify(payload);
        }

        // Pin the API version when the (sub)class defines one. Unversioned
        // requests get the API's latest behavior, which can validate
        // differently (e.g. day-2 delete rejected with 400 'Validation
        // Failure' where the versioned API accepts it).
        if (this.apiVersion) {
            uri +=
                (uri.indexOf("?") > -1 ? "&" : "?") +
                "apiVersion=" +
                this.apiVersion;
        }

        expectedStatusCodes = expectedStatusCodes || [200, 201, 202, 204];

        this.log.debug("Executing request: " + method + " " + uri);

        var request = this.restClient.createRequest(method, uri, content);

        request.setHeader("Content-Type", this.mediaType);
        request.setHeader("Accept", this.mediaType);

        var response = this.restClient.execute(request);
        var statusCode = response.statusCode;
        var responseContent = response.contentAsString;

        if (expectedStatusCodes.indexOf(statusCode) < 0) {
            throw new Error(
                "Request failed with unexpected status code '" +
                    statusCode +
                    "'. Response: " +
                    responseContent
            );
        }

        this.log.debug("Request completed with status '" + statusCode + "'");

        if (statusCode === 404) {
            return null;
        }

        var result;

        if (responseContent) {
            result = JSON.parse(responseContent);
        }

        return result;
    };

    /**
     * Defines the GET method. Collection responses are automatically
     * paginated and returned as a single list of results.
     * @function
     * @public
     * @param {string} uri - The request URI, relative to the host.
     * @param {Array/number} [expectedStatusCodes] - Expected status codes.
     * @returns {Any||Array/Any} The response result or results.
     */

    VraPluginRestClient.prototype.get = function (uri, expectedStatusCodes) {
        expectedStatusCodes = expectedStatusCodes || [200];

        var result;
        var results;
        var responseContent = this.executeRequest(
            "GET",
            uri,
            null,
            expectedStatusCodes
        );

        // Check if we have a collection.
        if (
            responseContent &&
            (responseContent.totalElements ||
                responseContent.totalElements === 0)
        ) {
            var numTotalResults = responseContent.totalElements;
            var numResultsOnPage = responseContent.numberOfElements;

            results = responseContent.content;

            this.log.debug(
                "Found " +
                    numResultsOnPage +
                    " of " +
                    numTotalResults +
                    " results"
            );

            if (numResultsOnPage > 0 && numResultsOnPage < numTotalResults) {
                // Get additional pages

                // Check if existing parameters are defined in the URI.
                if (uri.indexOf("?") > -1) {
                    uri += "&";
                } else {
                    uri += "?";
                }

                var pageSize = numResultsOnPage;

                do {
                    this.log.debug("Getting additional results");

                    var uriWithParams = uri + "$skip=" + numResultsOnPage;
                    var extraResponseContent = this.executeRequest(
                        "GET",
                        uriWithParams,
                        null,
                        expectedStatusCodes
                    );

                    results = results.concat(extraResponseContent.content);
                    this.log.debug(
                        "Found " +
                            results.length +
                            " of " +
                            numTotalResults +
                            " results"
                    );
                    numResultsOnPage += pageSize;
                } while (results.length < numTotalResults);
            }
        } else {
            result = responseContent;
        }

        return result || results;
    };

    /**
     * Defines the POST method.
     * @function
     * @public
     * @param {string} uri - The request URI, relative to the host.
     * @param {object} [payload] - The (optional) request payload.
     * @param {Array/number} [expectedStatusCodes] - Expected status codes.
     * @returns {Any} The response content object.
     */

    VraPluginRestClient.prototype.post = function (
        uri,
        payload,
        expectedStatusCodes
    ) {
        return this.executeRequest(
            "POST",
            uri,
            payload,
            expectedStatusCodes || [200, 201, 202]
        );
    };

    /**
     * Defines the PUT method.
     * @function
     * @public
     * @param {string} uri - The request URI, relative to the host.
     * @param {object} payload - The request payload.
     * @param {Array/number} [expectedStatusCodes] - Expected status codes.
     * @returns {Any} The response content object.
     */

    VraPluginRestClient.prototype.put = function (
        uri,
        payload,
        expectedStatusCodes
    ) {
        if (!payload || typeof payload !== "object") {
            throw new ReferenceError(
                "payload is required and must " + "be of type 'object'"
            );
        }

        return this.executeRequest(
            "PUT",
            uri,
            payload,
            expectedStatusCodes || [200, 201]
        );
    };

    /**
     * Defines the PATCH method.
     * @function
     * @public
     * @param {string} uri - The request URI, relative to the host.
     * @param {object} payload - The request payload.
     * @param {Array/number} [expectedStatusCodes] - Expected status codes.
     * @returns {Any} The response content object.
     */

    VraPluginRestClient.prototype.patch = function (
        uri,
        payload,
        expectedStatusCodes
    ) {
        if (!payload || typeof payload !== "object") {
            throw new ReferenceError(
                "payload is required and must " + "be of type 'object'"
            );
        }

        return this.executeRequest(
            "PATCH",
            uri,
            payload,
            expectedStatusCodes || [200, 201]
        );
    };

    /**
     * Defines the DELETE method.
     * @function
     * @public
     * @param {string} uri - The request URI, relative to the host.
     * @param {Array/number} [expectedStatusCodes] - Expected status codes.
     */

    VraPluginRestClient.prototype.delete = function (uri, expectedStatusCodes) {
        this.executeRequest("DELETE", uri, null, expectedStatusCodes || [204]);
    };

    return VraPluginRestClient;
});
